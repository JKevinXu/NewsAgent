"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const https = require("https");
const client_ses_1 = require("@aws-sdk/client-ses");
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
const client_polly_1 = require("@aws-sdk/client-polly");
const client_s3_1 = require("@aws-sdk/client-s3");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const handler = async (event, context) => {
    console.log('🤖 NewsAgent Lambda function started!');
    console.log('Event source:', event.source || 'direct-invocation');
    const currentTime = new Date().toISOString();
    try {
        // Fetch content from multiple sources
        console.log('📰 Fetching top stories from Hacker News...');
        const topStories = await getTopHackerNewsStories(3); // Get top 3 stories
        console.log('🏆 Fetching top products from Product Hunt...');
        const topProducts = await getTopProductHuntPosts(3); // Get top 3 products
        console.log('⭐ Fetching trending GitHub repositories...');
        const trendingRepos = await getTopGitHubTrending(3); // Get top 3 repos
        console.log(`📊 Found ${topStories.length} Hacker News stories, ${topProducts.length} Product Hunt posts, and ${trendingRepos.length} GitHub repositories`);
        // Process each story/product to get basic info and summaries
        const stories = [];
        // Process Hacker News stories
        for (const story of topStories) {
            try {
                const storyInfo = await processStoryWithSummary(story);
                stories.push(storyInfo);
                console.log(`✅ Processed HN: "${storyInfo.title}" (${storyInfo.score} points, ${storyInfo.comments} comments)`);
                if (storyInfo.summary) {
                    console.log(`📝 Summary: ${storyInfo.summary}`);
                }
            }
            catch (error) {
                console.log(`❌ Failed to process HN story: ${story.title}`, error);
            }
        }
        // Process Product Hunt posts
        for (const product of topProducts) {
            try {
                const productInfo = await processProductHuntPost(product);
                stories.push(productInfo);
                console.log(`✅ Processed PH: "${productInfo.title}" (${productInfo.score} votes, ${productInfo.comments} comments)`);
                if (productInfo.summary) {
                    console.log(`📝 Summary: ${productInfo.summary}`);
                }
            }
            catch (error) {
                console.log(`❌ Failed to process PH product: ${product.name}`, error);
            }
        }
        // Process GitHub trending repositories
        for (const repo of trendingRepos) {
            try {
                const repoInfo = await processGitHubRepository(repo);
                stories.push(repoInfo);
                console.log(`✅ Processed GitHub: "${repoInfo.title}" (${repoInfo.score} stars, ${repoInfo.comments} issues)`);
                if (repoInfo.summary) {
                    console.log(`📝 Summary: ${repoInfo.summary}`);
                }
            }
            catch (error) {
                console.log(`❌ Failed to process GitHub repo: ${repo.full_name}`, error);
            }
        }
        // Log comprehensive summary
        console.log('\n=== 📈 HACKER NEWS TOP STORIES ===');
        console.log(`📅 Generated at: ${currentTime}`);
        console.log(`📊 Total stories processed: ${stories.length}`);
        console.log('');
        stories.forEach((story, index) => {
            console.log(`${index + 1}. 📰 ${story.title}`);
            console.log(`   👤 Author: ${story.author} | ⭐ Score: ${story.score} points | 💬 ${story.comments} comments`);
            console.log(`   🔗 URL: ${story.url}`);
            if (story.summary) {
                console.log(`   💡 Key Insights: ${story.summary}`);
            }
            console.log('');
        });
        console.log('=== END SUMMARY ===\n');
        // Filter stories with summaries for combined audio
        const storiesWithSummaries = stories.filter(story => story.summary && story.summary !== 'Summary unavailable');
        // Generate combined audio for all summaries
        let combinedAudioUrl;
        if (storiesWithSummaries.length > 0) {
            combinedAudioUrl = await generateCombinedAudio(storiesWithSummaries, currentTime);
        }
        // Prepare newsletter data
        const newsletterData = {
            stories: storiesWithSummaries,
            combinedAudioUrl
        };
        // Save recommendations to database
        try {
            await saveDailyRecommendations(stories, currentTime, combinedAudioUrl);
            console.log('💾 Daily recommendations saved to database successfully');
        }
        catch (error) {
            console.error('❌ Failed to save recommendations to database:', error);
        }
        // Send email summary
        let emailSent = false;
        try {
            await sendEmailSummary(newsletterData, currentTime);
            emailSent = true;
            console.log('📧 Email summary sent successfully to xkevinj@gmail.com');
        }
        catch (error) {
            console.error('❌ Failed to send email:', error);
        }
        const result = {
            statusCode: 200,
            message: 'NewsAgent completed successfully',
            timestamp: currentTime,
            source: event.source === 'aws.events' ? 'scheduled-event' : 'manual-invocation',
            data: {
                storiesProcessed: stories.length,
                stories: stories,
                emailSent: emailSent,
                combinedAudioUrl: combinedAudioUrl
            }
        };
        // If this is triggered by EventBridge, return simple response
        if (event.source === 'aws.events') {
            console.log('🔄 Triggered by scheduled cron job');
            return result;
        }
        // If this is an API Gateway request, return proper API Gateway response
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type',
            },
            body: JSON.stringify(result),
        };
    }
    catch (error) {
        console.error('💥 NewsAgent encountered an error:', error);
        const errorResult = {
            statusCode: 500,
            message: 'NewsAgent failed',
            timestamp: currentTime,
            error: error instanceof Error ? error.message : 'Unknown error'
        };
        if (event.source === 'aws.events') {
            return errorResult;
        }
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify(errorResult),
        };
    }
};
exports.handler = handler;
async function httpGet(url, headers = {}) {
    return new Promise((resolve, reject) => {
        const urlObj = new URL(url);
        const options = {
            hostname: urlObj.hostname,
            port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
            path: urlObj.pathname + urlObj.search,
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (compatible; NewsAgent/1.0)',
                ...headers
            },
            timeout: 10000
        };
        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            res.on('end', () => {
                if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
                    resolve(data);
                }
                else {
                    reject(new Error(`HTTP ${res.statusCode}: ${res.statusMessage}`));
                }
            });
        });
        req.on('error', (error) => {
            reject(error);
        });
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });
        req.end();
    });
}
async function getTopHackerNewsStories(limit = 5) {
    try {
        // Get top story IDs
        const topStoriesData = await httpGet('https://hacker-news.firebaseio.com/v0/topstories.json');
        const topStoryIds = JSON.parse(topStoriesData).slice(0, limit);
        // Fetch details for each story
        const stories = [];
        for (const storyId of topStoryIds) {
            try {
                const storyData = await httpGet(`https://hacker-news.firebaseio.com/v0/item/${storyId}.json`);
                const story = JSON.parse(storyData);
                if (story && story.type === 'story' && story.url) {
                    stories.push(story);
                }
            }
            catch (error) {
                console.log(`Failed to fetch story ${storyId}:`, error);
            }
        }
        return stories;
    }
    catch (error) {
        console.error('Failed to fetch Hacker News stories:', error);
        throw error;
    }
}
async function getTopGitHubTrending(limit = 2) {
    try {
        console.log('⭐ Fetching GitHub trending repositories...');
        // Get repositories created in the last week, sorted by stars
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
        const dateString = oneWeekAgo.toISOString().split('T')[0];
        const apiUrl = `https://api.github.com/search/repositories?q=created:>${dateString}&sort=stars&order=desc&per_page=${limit}`;
        const headers = {
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Mozilla/5.0 (compatible; NewsAgent/1.0)'
        };
        const response = await httpGet(apiUrl, headers);
        const data = JSON.parse(response);
        if (data.items && data.items.length > 0) {
            console.log(`⭐ Found ${data.items.length} trending GitHub repositories`);
            return data.items.slice(0, limit);
        }
        else {
            console.log('⭐ No trending repositories found, using fallback');
            return [];
        }
    }
    catch (error) {
        console.error('Failed to fetch GitHub trending repositories:', error);
        return [];
    }
}
async function getTopProductHuntPosts(limit = 3) {
    try {
        console.log('🏆 Fetching Product Hunt posts (using curated trending products)...');
        // For now, let's use a curated list of trending tech products
        // This can be improved later with proper Product Hunt API integration
        const trendingProducts = [
            {
                name: "ChatGPT Desktop App",
                tagline: "The official ChatGPT desktop application for seamless AI conversations",
                website: "https://openai.com/chatgpt/desktop"
            },
            {
                name: "Cursor AI Editor",
                tagline: "AI-first code editor built for pair programming with AI",
                website: "https://cursor.sh"
            },
            {
                name: "Linear",
                tagline: "The issue tracking tool you'll enjoy using",
                website: "https://linear.app"
            },
            {
                name: "Vercel v0",
                tagline: "Generate UI with shadcn/ui from simple text prompts and images",
                website: "https://v0.dev"
            },
            {
                name: "Supabase",
                tagline: "The open source Firebase alternative",
                website: "https://supabase.com"
            }
        ];
        const posts = [];
        // Randomly select some products and simulate votes
        const shuffled = trendingProducts.sort(() => 0.5 - Math.random());
        const selected = shuffled.slice(0, Math.min(limit, trendingProducts.length));
        selected.forEach((product, index) => {
            const baseVotes = 150;
            const randomVotes = Math.floor(Math.random() * 300) + baseVotes;
            posts.push({
                id: `ph-trending-${index}`,
                name: product.name,
                tagline: product.tagline,
                description: product.tagline,
                featured_at: new Date().toISOString(),
                votes_count: randomVotes,
                comments_count: Math.floor(Math.random() * 50) + 10,
                website: product.website,
                redirect_url: product.website,
                screenshot_url: {
                    "300px": "",
                    "850px": ""
                },
                maker_inside: true
            });
        });
        console.log(`🏆 Generated ${posts.length} trending product entries`);
        return posts;
    }
    catch (error) {
        console.error('Failed to fetch Product Hunt posts:', error);
        // Return empty array on failure to not break the main flow
        return [];
    }
}
async function processStoryWithSummary(story) {
    const basicInfo = {
        title: story.title,
        url: story.url || 'No URL available',
        score: story.score,
        author: story.by,
        comments: story.descendants || 0,
        timestamp: new Date(story.time * 1000).toISOString(),
        source: 'hacker-news'
    };
    // Try to fetch and summarize article content
    if (story.url && story.url !== 'No URL available') {
        try {
            const articleContent = await fetchArticleContent(story.url);
            if (articleContent && articleContent !== 'Unable to fetch article content') {
                const summary = await summarizeWithBedrock(story.title, articleContent);
                basicInfo.summary = summary;
                // Generate audio for the summary
                if (summary && summary !== 'Summary unavailable') {
                    const audioUrl = await generateAudio(story.title, summary);
                    basicInfo.audioUrl = audioUrl;
                }
            }
        }
        catch (error) {
            console.error(`Failed to summarize article: ${story.title}`, error);
            // Continue without summary rather than failing completely
        }
    }
    return basicInfo;
}
async function processProductHuntPost(post) {
    const basicInfo = {
        title: post.name,
        url: post.website || post.redirect_url,
        score: post.votes_count,
        author: 'Product Hunt',
        comments: post.comments_count,
        timestamp: post.featured_at,
        source: 'product-hunt'
    };
    // Create a summary from the Product Hunt post data
    const productSummary = `## Summary\n\n${post.name} is a new product featured on Product Hunt. ${post.tagline} ${post.description ? post.description : ''}\n\n## Key Insight\n\nThis product has gained ${post.votes_count} votes on Product Hunt, indicating strong community interest and potential market demand.`;
    basicInfo.summary = productSummary;
    // Generate audio for the Product Hunt post summary
    if (basicInfo.summary) {
        const audioUrl = await generateAudio(basicInfo.title, basicInfo.summary);
        basicInfo.audioUrl = audioUrl;
    }
    return basicInfo;
}
async function processGitHubRepository(repo) {
    const basicInfo = {
        title: repo.full_name,
        url: repo.html_url,
        score: repo.stargazers_count,
        author: repo.owner.login,
        comments: 0,
        timestamp: repo.created_at,
        source: 'github-trending'
    };
    // Create a summary from the GitHub repository data
    const repoSummary = `## Summary\n\n${repo.full_name} is a trending GitHub repository${repo.language ? ` written in ${repo.language}` : ''}. ${repo.description || 'No description provided.'}\n\n## Key Insight\n\nThis repository has gained ${repo.stargazers_count} stars, indicating strong developer interest and potential utility. The project represents current trends in the open-source development community.`;
    basicInfo.summary = repoSummary;
    // Generate audio for the GitHub repository summary
    if (basicInfo.summary) {
        const audioUrl = await generateAudio(basicInfo.title, basicInfo.summary);
        basicInfo.audioUrl = audioUrl;
    }
    return basicInfo;
}
async function fetchArticleContent(url) {
    try {
        console.log(`📖 Fetching article content from: ${url}`);
        const content = await httpGet(url);
        // Simple text extraction - remove HTML tags and extract meaningful content
        const textContent = content
            .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove scripts
            .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '') // Remove styles
            .replace(/<[^>]*>/g, ' ') // Remove HTML tags
            .replace(/\s+/g, ' ') // Normalize whitespace
            .trim();
        // Take first 4000 characters to avoid token limits
        const truncatedContent = textContent.length > 4000 ? textContent.substring(0, 4000) + '...' : textContent;
        return truncatedContent;
    }
    catch (error) {
        console.error(`❌ Failed to fetch article content from ${url}:`, error);
        return 'Unable to fetch article content';
    }
}
async function summarizeWithBedrock(title, content) {
    try {
        console.log(`🤖 Generating summary for: ${title}`);
        const bedrockClient = new client_bedrock_runtime_1.BedrockRuntimeClient({
            region: process.env.AWS_REGION || 'us-west-2'
        });
        const prompt = `Human: Please analyze this article and provide exactly 2 parts:

1. **Summary**: A concise overview of what the article is about and its main points
2. **Key Insight**: The single most interesting, surprising, or valuable takeaway that makes this article worth reading

Keep both parts brief and focused. Do not repeat the article title in your response.

Article content:
${content}

Assistant:`;
        const body = {
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 1000,
            messages: [
                {
                    role: "user",
                    content: prompt
                }
            ]
        };
        const command = new client_bedrock_runtime_1.InvokeModelCommand({
            modelId: "us.anthropic.claude-3-7-sonnet-20250219-v1:0",
            contentType: "application/json",
            body: JSON.stringify(body)
        });
        const response = await bedrockClient.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        return responseBody.content[0].text.trim();
    }
    catch (error) {
        console.error(`❌ Failed to summarize with Bedrock:`, error);
        return 'Summary unavailable';
    }
}
async function generateAudio(title, summary) {
    try {
        console.log(`🎵 Generating audio for: ${title}`);
        const pollyClient = new client_polly_1.PollyClient({
            region: process.env.AWS_REGION || 'us-west-2'
        });
        const s3Client = new client_s3_1.S3Client({
            region: process.env.AWS_REGION || 'us-west-2'
        });
        // Clean text for speech synthesis
        const speechText = summary
            .replace(/^#+\s*/gm, '') // Remove markdown headers
            .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold formatting
            .replace(/\*(.*?)\*/g, '$1') // Remove italic formatting
            .replace(/\n+/g, ' ') // Replace line breaks with spaces
            .trim();
        // Generate speech with Polly
        const synthesizeCommand = new client_polly_1.SynthesizeSpeechCommand({
            Text: speechText,
            OutputFormat: 'mp3',
            VoiceId: 'Joanna',
            Engine: 'neural'
        });
        const pollyResponse = await pollyClient.send(synthesizeCommand);
        if (!pollyResponse.AudioStream) {
            throw new Error('No audio stream received from Polly');
        }
        // Convert audio stream to buffer
        const audioBuffer = await streamToBuffer(pollyResponse.AudioStream);
        // Generate unique filename
        const timestamp = new Date().toISOString().slice(0, 10);
        const titleSlug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50);
        const filename = `audio/${timestamp}/${titleSlug}.mp3`;
        // Upload to S3
        const bucketName = process.env.AUDIO_BUCKET_NAME;
        if (!bucketName) {
            throw new Error('AUDIO_BUCKET_NAME environment variable not set');
        }
        const uploadCommand = new client_s3_1.PutObjectCommand({
            Bucket: bucketName,
            Key: filename,
            Body: audioBuffer,
            ContentType: 'audio/mpeg'
        });
        await s3Client.send(uploadCommand);
        const audioUrl = `https://${bucketName}.s3.${process.env.AWS_REGION || 'us-west-2'}.amazonaws.com/${filename}`;
        console.log(`🎵 Audio generated: ${audioUrl}`);
        return audioUrl;
    }
    catch (error) {
        console.error(`❌ Failed to generate audio:`, error);
        return undefined;
    }
}
async function generateCombinedAudio(stories, timestamp) {
    try {
        console.log(`🎵 Generating combined audio for ${stories.length} stories`);
        const pollyClient = new client_polly_1.PollyClient({
            region: process.env.AWS_REGION || 'us-west-2'
        });
        const s3Client = new client_s3_1.S3Client({
            region: process.env.AWS_REGION || 'us-west-2'
        });
        const audioBuffers = [];
        // Generate intro
        console.log('🎵 Generating intro audio...');
        const introText = "Welcome to your Hacker News daily digest. Here are today's top stories with AI-generated summaries.";
        const introBuffer = await generateSingleAudioBuffer(pollyClient, introText);
        if (introBuffer)
            audioBuffers.push(introBuffer);
        // Generate audio for each story individually
        for (let index = 0; index < stories.length; index++) {
            const story = stories[index];
            if (story.summary) {
                console.log(`🎵 Generating audio for story ${index + 1}: ${story.title}`);
                // Create title introduction
                const titleText = `Story ${index + 1}: ${story.title}.`;
                const titleBuffer = await generateSingleAudioBuffer(pollyClient, titleText);
                if (titleBuffer)
                    audioBuffers.push(titleBuffer);
                // Clean the full summary for audio (keep complete summary)
                const cleanSummary = story.summary
                    .replace(/^#+\s*/gm, '') // Remove markdown headers
                    .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold formatting
                    .replace(/\*(.*?)\*/g, '$1') // Remove italic formatting
                    .replace(/\n+/g, ' ') // Replace line breaks with spaces
                    .trim();
                // Split long summaries into chunks if needed (Polly has 3000 char limit)
                const summaryChunks = splitTextIntoChunks(cleanSummary, 2500);
                // Generate audio for each chunk of the summary
                for (const chunk of summaryChunks) {
                    const chunkBuffer = await generateSingleAudioBuffer(pollyClient, chunk);
                    if (chunkBuffer)
                        audioBuffers.push(chunkBuffer);
                }
                // Add a small pause between stories
                if (index < stories.length - 1) {
                    const pauseBuffer = await generateSingleAudioBuffer(pollyClient, "Next story.");
                    if (pauseBuffer)
                        audioBuffers.push(pauseBuffer);
                }
            }
        }
        // Generate outro
        console.log('🎵 Generating outro audio...');
        const outroText = "That concludes today's Hacker News digest. Thank you for listening.";
        const outroBuffer = await generateSingleAudioBuffer(pollyClient, outroText);
        if (outroBuffer)
            audioBuffers.push(outroBuffer);
        if (audioBuffers.length === 0) {
            throw new Error('No audio buffers were generated');
        }
        // Concatenate all audio buffers
        console.log(`🎵 Concatenating ${audioBuffers.length} audio segments...`);
        const combinedBuffer = Buffer.concat(audioBuffers);
        // Generate unique filename for combined audio
        const dateStamp = new Date().toISOString().slice(0, 10);
        const filename = `audio/${dateStamp}/daily-digest-${Date.now()}.mp3`;
        // Upload to S3
        const bucketName = process.env.AUDIO_BUCKET_NAME;
        if (!bucketName) {
            throw new Error('AUDIO_BUCKET_NAME environment variable not set');
        }
        const uploadCommand = new client_s3_1.PutObjectCommand({
            Bucket: bucketName,
            Key: filename,
            Body: combinedBuffer,
            ContentType: 'audio/mpeg'
        });
        await s3Client.send(uploadCommand);
        const audioUrl = `https://${bucketName}.s3.${process.env.AWS_REGION || 'us-west-2'}.amazonaws.com/${filename}`;
        console.log(`🎵 Combined audio generated: ${audioUrl}`);
        return audioUrl;
    }
    catch (error) {
        console.error(`❌ Failed to generate combined audio:`, error);
        return undefined;
    }
}
function splitTextIntoChunks(text, maxChunkSize) {
    if (text.length <= maxChunkSize) {
        return [text];
    }
    const chunks = [];
    let currentChunk = '';
    // Split by sentences to maintain natural breaks
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    for (const sentence of sentences) {
        const trimmedSentence = sentence.trim();
        if (!trimmedSentence)
            continue;
        const sentenceWithPunctuation = trimmedSentence + '.';
        // If adding this sentence would exceed the limit, save current chunk and start new one
        if (currentChunk.length + sentenceWithPunctuation.length + 1 > maxChunkSize) {
            if (currentChunk.trim()) {
                chunks.push(currentChunk.trim());
            }
            currentChunk = sentenceWithPunctuation;
        }
        else {
            currentChunk += (currentChunk ? ' ' : '') + sentenceWithPunctuation;
        }
    }
    // Add the last chunk if it has content
    if (currentChunk.trim()) {
        chunks.push(currentChunk.trim());
    }
    return chunks.length > 0 ? chunks : [text]; // Fallback to original text if no chunks created
}
async function generateSingleAudioBuffer(pollyClient, text) {
    try {
        // Ensure text is within Polly's limits (3000 characters)
        const truncatedText = text.length > 2800 ? text.substring(0, 2800) + "..." : text;
        const synthesizeCommand = new client_polly_1.SynthesizeSpeechCommand({
            Text: truncatedText,
            OutputFormat: 'mp3',
            VoiceId: 'Joanna',
            Engine: 'neural'
        });
        const pollyResponse = await pollyClient.send(synthesizeCommand);
        if (!pollyResponse.AudioStream) {
            console.error('No audio stream received from Polly');
            return null;
        }
        return await streamToBuffer(pollyResponse.AudioStream);
    }
    catch (error) {
        console.error(`❌ Failed to generate single audio buffer:`, error);
        return null;
    }
}
async function streamToBuffer(stream) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on('data', (chunk) => {
            chunks.push(chunk);
        });
        stream.on('end', () => {
            resolve(Buffer.concat(chunks));
        });
        stream.on('error', (error) => {
            reject(error);
        });
    });
}
async function saveDailyRecommendations(stories, timestamp, combinedAudioUrl) {
    const dynamoClient = new client_dynamodb_1.DynamoDBClient({
        region: process.env.AWS_REGION || 'us-west-2'
    });
    const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
    const tableName = process.env.RECOMMENDATIONS_TABLE_NAME;
    if (!tableName) {
        throw new Error('RECOMMENDATIONS_TABLE_NAME environment variable not set');
    }
    const date = new Date(timestamp).toISOString().split('T')[0]; // YYYY-MM-DD format
    const oneYearFromNow = Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60); // TTL in seconds
    console.log(`💾 Saving ${stories.length} recommendations for date: ${date}`);
    // Save individual story recommendations
    const putRequests = stories.map((story, index) => ({
        PutRequest: {
            Item: {
                id: `${story.source}-${index}-${Date.now()}`,
                date: date,
                source: story.source,
                title: story.title,
                url: story.url,
                score: story.score,
                author: story.author,
                comments: story.comments,
                timestamp: story.timestamp,
                summary: story.summary || '',
                audioUrl: story.audioUrl || '',
                ttl: oneYearFromNow
            }
        }
    }));
    // Save daily digest metadata
    const digestRecord = {
        id: `digest-${date}`,
        date: date,
        source: 'daily-digest',
        totalStories: stories.length,
        timestamp: timestamp,
        combinedAudioUrl: combinedAudioUrl || '',
        emailSent: false,
        ttl: oneYearFromNow
    };
    try {
        // Batch write individual recommendations (max 25 items per batch)
        const batches = [];
        for (let i = 0; i < putRequests.length; i += 25) {
            batches.push(putRequests.slice(i, i + 25));
        }
        for (const batch of batches) {
            const batchWriteCommand = new lib_dynamodb_1.BatchWriteCommand({
                RequestItems: {
                    [tableName]: batch
                }
            });
            await docClient.send(batchWriteCommand);
        }
        // Save digest record
        const putDigestCommand = new lib_dynamodb_1.PutCommand({
            TableName: tableName,
            Item: digestRecord
        });
        await docClient.send(putDigestCommand);
        console.log(`✅ Successfully saved ${stories.length} recommendations and digest for ${date}`);
    }
    catch (error) {
        console.error('❌ Failed to save recommendations to database:', error);
        throw error;
    }
}
async function updateEmailSentStatus(timestamp) {
    const dynamoClient = new client_dynamodb_1.DynamoDBClient({
        region: process.env.AWS_REGION || 'us-west-2'
    });
    const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
    const tableName = process.env.RECOMMENDATIONS_TABLE_NAME;
    if (!tableName) {
        throw new Error('RECOMMENDATIONS_TABLE_NAME environment variable not set');
    }
    const date = new Date(timestamp).toISOString().split('T')[0];
    try {
        const putCommand = new lib_dynamodb_1.PutCommand({
            TableName: tableName,
            Item: {
                id: `digest-${date}`,
                emailSent: true,
                lastUpdated: timestamp
            },
            ConditionExpression: 'attribute_exists(#id)',
            ExpressionAttributeNames: {
                '#id': 'id'
            }
        });
        await docClient.send(putCommand);
        console.log(`✅ Updated email sent status for ${date}`);
    }
    catch (error) {
        console.error('❌ Failed to update email sent status:', error);
        // Don't throw error here as it's not critical
    }
}
async function sendEmailSummary(newsletterData, timestamp) {
    const sesClient = new client_ses_1.SESClient({
        region: process.env.AWS_REGION || 'us-west-2'
    });
    // Create HTML email content
    const htmlContent = generateEmailHTML(newsletterData, timestamp);
    const textContent = generateEmailText(newsletterData, timestamp);
    const params = {
        Destination: {
            ToAddresses: ['xkevinj@gmail.com']
        },
        Message: {
            Body: {
                Html: {
                    Charset: 'UTF-8',
                    Data: htmlContent
                },
                Text: {
                    Charset: 'UTF-8',
                    Data: textContent
                }
            },
            Subject: {
                Charset: 'UTF-8',
                Data: `📰 Hacker News Summary - ${new Date(timestamp).toLocaleDateString()}`
            }
        },
        Source: process.env.SES_FROM_EMAIL || 'newsagent@example.com' // You'll need to verify this email in SES
    };
    const command = new client_ses_1.SendEmailCommand(params);
    await sesClient.send(command);
    // Update database with email sent status
    try {
        await updateEmailSentStatus(timestamp);
    }
    catch (error) {
        console.error('❌ Failed to update email sent status in database:', error);
        // Don't fail the email send for this
    }
}
function generateEmailHTML(newsletterData, timestamp) {
    const date = new Date(timestamp).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZoneName: 'short'
    });
    // Add "Play All" button if combined audio is available
    let playAllSection = '';
    if (newsletterData.combinedAudioUrl) {
        playAllSection = `
      <div style="margin-bottom: 30px; padding: 20px; background-color: #f0f8ff; border-radius: 8px; text-align: center; border: 2px solid #ff6600;">
        <h2 style="color: #ff6600; font-size: 20px; margin: 0 0 15px 0;">🎧 Listen to All Stories</h2>
        <a href="${newsletterData.combinedAudioUrl}" style="display: inline-block; padding: 15px 30px; background-color: #ff6600; color: white; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px; box-shadow: 0 4px 8px rgba(255,102,0,0.3);">
          🎵 Play Full Daily Digest
        </a>
        <p style="margin: 10px 0 0 0; font-size: 14px; color: #666;">Listen to all ${newsletterData.stories.length} story summaries in one continuous audio</p>
      </div>`;
    }
    let storiesHTML = '';
    newsletterData.stories.forEach((story, index) => {
        let sourceIcon, sourceColor, sourceName;
        if (story.source === 'hacker-news') {
            sourceIcon = '📰';
            sourceColor = '#ff6600';
            sourceName = 'Hacker News';
        }
        else if (story.source === 'product-hunt') {
            sourceIcon = '🏆';
            sourceColor = '#da552f';
            sourceName = 'Product Hunt';
        }
        else if (story.source === 'github-trending') {
            sourceIcon = '⭐';
            sourceColor = '#24292e';
            sourceName = 'GitHub Trending';
        }
        storiesHTML += `
        <div style="margin-bottom: 25px; padding: 15px; background-color: #f9f9f9; border-left: 4px solid ${sourceColor};">
          <div style="display: flex; align-items: center; margin-bottom: 8px;">
            <span style="background-color: ${sourceColor}; color: white; padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: bold; margin-right: 10px;">
              ${sourceIcon} ${sourceName}
            </span>
          </div>
        <h3 style="margin: 0 0 10px 0; color: #333;">
            ${index + 1}. <a href="${story.url}" style="color: ${sourceColor}; text-decoration: none;">${story.title}</a>
        </h3>
        <p style="margin: 5px 0; color: #888; font-size: 12px;">
          🕐 Posted: ${new Date(story.timestamp).toLocaleString()}
          </p>`;
        if (story.summary) {
            // Convert markdown to HTML for better rendering
            const htmlSummary = story.summary
                .replace(/^#+\s*/gm, '') // Remove all markdown headers (# ## ### etc)
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>')
                .replace(/^\d+\. (.*)/gm, '<div style="margin: 8px 0; padding-left: 15px;"><strong>• $1</strong></div>')
                .replace(/\n\n/g, '</p><p style="margin: 8px 0; line-height: 1.6;">')
                .replace(/\n/g, '<br>');
            storiesHTML += `
        <div style="margin-top: 15px; padding: 20px; background-color: #fff; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <div style="color: #444; font-size: 14px; line-height: 1.6;">
            <p style="margin: 8px 0; line-height: 1.6;">${htmlSummary}</p>
          </div>`;
            storiesHTML += `
        </div>`;
        }
        storiesHTML += `
      </div>
    `;
    });
    return `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Hacker News Summary</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px; padding: 20px; background: linear-gradient(135deg, #ff6600, #da552f); color: white; border-radius: 8px;">
            <h1 style="margin: 0;">🚀 Daily Tech Digest</h1>
            <p style="margin: 10px 0 0 0;">Hacker News • Product Hunt • GitHub Trending</p>
            <p style="margin: 5px 0 0 0; font-size: 14px;">${date}</p>
        </div>
        
        ${playAllSection}
        
        <div style="margin-bottom: 20px;">
            <h2 style="color: #ff6600;">🔥 Top ${newsletterData.stories.length} Stories</h2>
            ${storiesHTML}
        </div>
        
        <div style="text-align: center; margin-top: 30px; padding: 15px; background-color: #f0f0f0; border-radius: 6px; font-size: 12px; color: #666;">
            <p>This summary was automatically generated by your NewsAgent Lambda function.</p>
            <p>🤖 Powered by AWS Lambda, Bedrock & Hacker News API</p>
        </div>
    </body>
    </html>
  `;
}
function generateEmailText(newsletterData, timestamp) {
    const date = new Date(timestamp).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZoneName: 'short'
    });
    // Add "Play All" button if combined audio is available
    let playAllText = '';
    if (newsletterData.combinedAudioUrl) {
        playAllText = `
🎧 LISTEN TO ALL STORIES
Play Full Daily Digest: ${newsletterData.combinedAudioUrl}
Listen to all ${newsletterData.stories.length} story summaries in one continuous audio

---

`;
    }
    let storiesText = '';
    newsletterData.stories.forEach((story, index) => {
        let sourceLabel;
        if (story.source === 'hacker-news') {
            sourceLabel = '📰 Hacker News';
        }
        else if (story.source === 'product-hunt') {
            sourceLabel = '🏆 Product Hunt';
        }
        else if (story.source === 'github-trending') {
            sourceLabel = '⭐ GitHub Trending';
        }
        storiesText += `
${index + 1}. ${story.title} [${sourceLabel}]
   URL: ${story.url}
   Posted: ${new Date(story.timestamp).toLocaleString()}`;
        if (story.summary) {
            // Clean up markdown for plain text email
            const cleanSummary = story.summary
                .replace(/^#+\s*/gm, '') // Remove all markdown headers
                .replace(/\*\*(.*?)\*\*/g, '$1')
                .replace(/\*(.*?)\*/g, '$1')
                .replace(/^\d+\. /gm, '   → ');
            storiesText += `
   
${cleanSummary}`;
        }
        storiesText += `

`;
    });
    return `
DAILY TECH DIGEST
Hacker News • Product Hunt • GitHub Trending
Generated by NewsAgent with AI Summaries
${date}

${playAllText}Top ${newsletterData.stories.length} Items:
${storiesText}
---
This summary was automatically generated by your NewsAgent Lambda function.
Powered by AWS Lambda, Bedrock & Hacker News API
  `;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVsbG8td29ybGQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJoZWxsby13b3JsZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSwrQkFBK0I7QUFDL0Isb0RBQWtFO0FBQ2xFLDRFQUEyRjtBQUMzRix3REFBNkU7QUFDN0Usa0RBQWdFO0FBQ2hFLDhEQUEwRDtBQUMxRCx3REFBOEY7QUF3RnZGLE1BQU0sT0FBTyxHQUFHLEtBQUssRUFDMUIsS0FBaUMsRUFDakMsT0FBZ0IsRUFDc0IsRUFBRTtJQUN4QyxPQUFPLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7SUFDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyxDQUFDO0lBRWxFLE1BQU0sV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7SUFFN0MsSUFBSTtRQUNGLHNDQUFzQztRQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLDZDQUE2QyxDQUFDLENBQUM7UUFDM0QsTUFBTSxVQUFVLEdBQUcsTUFBTSx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQjtRQUV6RSxPQUFPLENBQUMsR0FBRyxDQUFDLCtDQUErQyxDQUFDLENBQUM7UUFDN0QsTUFBTSxXQUFXLEdBQUcsTUFBTSxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQjtRQUUxRSxPQUFPLENBQUMsR0FBRyxDQUFDLDRDQUE0QyxDQUFDLENBQUM7UUFDMUQsTUFBTSxhQUFhLEdBQUcsTUFBTSxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtRQUV2RSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksVUFBVSxDQUFDLE1BQU0seUJBQXlCLFdBQVcsQ0FBQyxNQUFNLDRCQUE0QixhQUFhLENBQUMsTUFBTSxzQkFBc0IsQ0FBQyxDQUFDO1FBRTVKLDZEQUE2RDtRQUM3RCxNQUFNLE9BQU8sR0FBZ0IsRUFBRSxDQUFDO1FBRWhDLDhCQUE4QjtRQUM5QixLQUFLLE1BQU0sS0FBSyxJQUFJLFVBQVUsRUFBRTtZQUM5QixJQUFJO2dCQUNGLE1BQU0sU0FBUyxHQUFHLE1BQU0sdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3ZELE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFNBQVMsQ0FBQyxLQUFLLE1BQU0sU0FBUyxDQUFDLEtBQUssWUFBWSxTQUFTLENBQUMsUUFBUSxZQUFZLENBQUMsQ0FBQztnQkFDaEgsSUFBSSxTQUFTLENBQUMsT0FBTyxFQUFFO29CQUNyQixPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7aUJBQ2pEO2FBQ0Y7WUFBQyxPQUFPLEtBQUssRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDcEU7U0FDRjtRQUVELDZCQUE2QjtRQUM3QixLQUFLLE1BQU0sT0FBTyxJQUFJLFdBQVcsRUFBRTtZQUNqQyxJQUFJO2dCQUNGLE1BQU0sV0FBVyxHQUFHLE1BQU0sc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzFELE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFdBQVcsQ0FBQyxLQUFLLE1BQU0sV0FBVyxDQUFDLEtBQUssV0FBVyxXQUFXLENBQUMsUUFBUSxZQUFZLENBQUMsQ0FBQztnQkFDckgsSUFBSSxXQUFXLENBQUMsT0FBTyxFQUFFO29CQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7aUJBQ25EO2FBQ0Y7WUFBQyxPQUFPLEtBQUssRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDdkU7U0FDRjtRQUVELHVDQUF1QztRQUN2QyxLQUFLLE1BQU0sSUFBSSxJQUFJLGFBQWEsRUFBRTtZQUNoQyxJQUFJO2dCQUNGLE1BQU0sUUFBUSxHQUFHLE1BQU0sdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3JELE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3ZCLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLFFBQVEsQ0FBQyxLQUFLLE1BQU0sUUFBUSxDQUFDLEtBQUssV0FBVyxRQUFRLENBQUMsUUFBUSxVQUFVLENBQUMsQ0FBQztnQkFDOUcsSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFO29CQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7aUJBQ2hEO2FBQ0Y7WUFBQyxPQUFPLEtBQUssRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDMUU7U0FDRjtRQUVELDRCQUE0QjtRQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7UUFDcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUMvQyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUM3RCxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRWhCLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUU7WUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLFFBQVEsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsS0FBSyxDQUFDLE1BQU0sZUFBZSxLQUFLLENBQUMsS0FBSyxnQkFBZ0IsS0FBSyxDQUFDLFFBQVEsV0FBVyxDQUFDLENBQUM7WUFDOUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZDLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtnQkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDckQ7WUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2xCLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBRXJDLG1EQUFtRDtRQUNuRCxNQUFNLG9CQUFvQixHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLEtBQUsscUJBQXFCLENBQUMsQ0FBQztRQUUvRyw0Q0FBNEM7UUFDNUMsSUFBSSxnQkFBb0MsQ0FBQztRQUN6QyxJQUFJLG9CQUFvQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDbkMsZ0JBQWdCLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxvQkFBb0IsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUNuRjtRQUVELDBCQUEwQjtRQUMxQixNQUFNLGNBQWMsR0FBbUI7WUFDckMsT0FBTyxFQUFFLG9CQUFvQjtZQUM3QixnQkFBZ0I7U0FDakIsQ0FBQztRQUVGLG1DQUFtQztRQUNuQyxJQUFJO1lBQ0YsTUFBTSx3QkFBd0IsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFDdkUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO1NBQ3hFO1FBQUMsT0FBTyxLQUFLLEVBQUU7WUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLCtDQUErQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ3ZFO1FBRUQscUJBQXFCO1FBQ3JCLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJO1lBQ0YsTUFBTSxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDcEQsU0FBUyxHQUFHLElBQUksQ0FBQztZQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLHlEQUF5RCxDQUFDLENBQUM7U0FDeEU7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDakQ7UUFFRCxNQUFNLE1BQU0sR0FBRztZQUNiLFVBQVUsRUFBRSxHQUFHO1lBQ2YsT0FBTyxFQUFFLGtDQUFrQztZQUMzQyxTQUFTLEVBQUUsV0FBVztZQUN0QixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxtQkFBbUI7WUFDL0UsSUFBSSxFQUFFO2dCQUNKLGdCQUFnQixFQUFFLE9BQU8sQ0FBQyxNQUFNO2dCQUNoQyxPQUFPLEVBQUUsT0FBTztnQkFDaEIsU0FBUyxFQUFFLFNBQVM7Z0JBQ3BCLGdCQUFnQixFQUFFLGdCQUFnQjthQUNuQztTQUNGLENBQUM7UUFFRiw4REFBOEQ7UUFDOUQsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLFlBQVksRUFBRTtZQUNqQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7WUFDbEQsT0FBTyxNQUFNLENBQUM7U0FDZjtRQUVELHdFQUF3RTtRQUN4RSxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUU7Z0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtnQkFDbEMsNkJBQTZCLEVBQUUsR0FBRztnQkFDbEMsOEJBQThCLEVBQUUsb0JBQW9CO2dCQUNwRCw4QkFBOEIsRUFBRSxjQUFjO2FBQy9DO1lBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO1NBQzdCLENBQUM7S0FFSDtJQUFDLE9BQU8sS0FBSyxFQUFFO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxvQ0FBb0MsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUUzRCxNQUFNLFdBQVcsR0FBRztZQUNsQixVQUFVLEVBQUUsR0FBRztZQUNmLE9BQU8sRUFBRSxrQkFBa0I7WUFDM0IsU0FBUyxFQUFFLFdBQVc7WUFDdEIsS0FBSyxFQUFFLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWU7U0FDaEUsQ0FBQztRQUVGLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxZQUFZLEVBQUU7WUFDakMsT0FBTyxXQUFXLENBQUM7U0FDcEI7UUFFRCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUU7Z0JBQ1AsY0FBYyxFQUFFLGtCQUFrQjtnQkFDbEMsNkJBQTZCLEVBQUUsR0FBRzthQUNuQztZQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQztTQUNsQyxDQUFDO0tBQ0g7QUFDSCxDQUFDLENBQUM7QUE1S1csUUFBQSxPQUFPLFdBNEtsQjtBQUVGLEtBQUssVUFBVSxPQUFPLENBQUMsR0FBVyxFQUFFLFVBQWtDLEVBQUU7SUFDdEUsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtRQUNyQyxNQUFNLE1BQU0sR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM1QixNQUFNLE9BQU8sR0FBRztZQUNkLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtZQUN6QixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUM5RCxJQUFJLEVBQUUsTUFBTSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTTtZQUNyQyxNQUFNLEVBQUUsS0FBSztZQUNiLE9BQU8sRUFBRTtnQkFDUCxZQUFZLEVBQUUseUNBQXlDO2dCQUN2RCxHQUFHLE9BQU87YUFDWDtZQUNELE9BQU8sRUFBRSxLQUFLO1NBQ2YsQ0FBQztRQUVGLE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBUSxFQUFFLEVBQUU7WUFDOUMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBRWQsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFVLEVBQUUsRUFBRTtnQkFDNUIsSUFBSSxJQUFJLEtBQUssQ0FBQztZQUNoQixDQUFDLENBQUMsQ0FBQztZQUVILEdBQUcsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRTtnQkFDakIsSUFBSSxHQUFHLENBQUMsVUFBVSxJQUFJLEdBQUcsQ0FBQyxVQUFVLElBQUksR0FBRyxJQUFJLEdBQUcsQ0FBQyxVQUFVLEdBQUcsR0FBRyxFQUFFO29CQUNuRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ2Y7cUJBQU07b0JBQ0wsTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLFVBQVUsS0FBSyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxDQUFDO2lCQUNuRTtZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxHQUFHLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQzdCLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztRQUVILEdBQUcsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRTtZQUNyQixHQUFHLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDZCxNQUFNLENBQUMsSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBRUgsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ1osQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQsS0FBSyxVQUFVLHVCQUF1QixDQUFDLFFBQWdCLENBQUM7SUFDdEQsSUFBSTtRQUNGLG9CQUFvQjtRQUNwQixNQUFNLGNBQWMsR0FBRyxNQUFNLE9BQU8sQ0FBQyx1REFBdUQsQ0FBQyxDQUFDO1FBQzlGLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUUvRCwrQkFBK0I7UUFDL0IsTUFBTSxPQUFPLEdBQXFCLEVBQUUsQ0FBQztRQUVyQyxLQUFLLE1BQU0sT0FBTyxJQUFJLFdBQVcsRUFBRTtZQUNqQyxJQUFJO2dCQUNGLE1BQU0sU0FBUyxHQUFHLE1BQU0sT0FBTyxDQUFDLDhDQUE4QyxPQUFPLE9BQU8sQ0FBQyxDQUFDO2dCQUM5RixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUVwQyxJQUFJLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLLENBQUMsR0FBRyxFQUFFO29CQUNoRCxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUNyQjthQUNGO1lBQUMsT0FBTyxLQUFLLEVBQUU7Z0JBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsT0FBTyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDekQ7U0FDRjtRQUVELE9BQU8sT0FBTyxDQUFDO0tBQ2hCO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLHNDQUFzQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzdELE1BQU0sS0FBSyxDQUFDO0tBQ2I7QUFDSCxDQUFDO0FBRUQsS0FBSyxVQUFVLG9CQUFvQixDQUFDLFFBQWdCLENBQUM7SUFDbkQsSUFBSTtRQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztRQUUxRCw2REFBNkQ7UUFDN0QsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUM5QixVQUFVLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUM3QyxNQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRTFELE1BQU0sTUFBTSxHQUFHLHlEQUF5RCxVQUFVLG1DQUFtQyxLQUFLLEVBQUUsQ0FBQztRQUU3SCxNQUFNLE9BQU8sR0FBRztZQUNkLFFBQVEsRUFBRSxnQ0FBZ0M7WUFDMUMsWUFBWSxFQUFFLHlDQUF5QztTQUN4RCxDQUFDO1FBRUYsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2hELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFbEMsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUN2QyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLCtCQUErQixDQUFDLENBQUM7WUFDekUsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDbkM7YUFBTTtZQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0RBQWtELENBQUMsQ0FBQztZQUNoRSxPQUFPLEVBQUUsQ0FBQztTQUNYO0tBQ0Y7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0NBQStDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDdEUsT0FBTyxFQUFFLENBQUM7S0FDWDtBQUNILENBQUM7QUFFRCxLQUFLLFVBQVUsc0JBQXNCLENBQUMsUUFBZ0IsQ0FBQztJQUNyRCxJQUFJO1FBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxRUFBcUUsQ0FBQyxDQUFDO1FBRW5GLDhEQUE4RDtRQUM5RCxzRUFBc0U7UUFDdEUsTUFBTSxnQkFBZ0IsR0FBRztZQUN2QjtnQkFDRSxJQUFJLEVBQUUscUJBQXFCO2dCQUMzQixPQUFPLEVBQUUsd0VBQXdFO2dCQUNqRixPQUFPLEVBQUUsb0NBQW9DO2FBQzlDO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLGtCQUFrQjtnQkFDeEIsT0FBTyxFQUFFLHlEQUF5RDtnQkFDbEUsT0FBTyxFQUFFLG1CQUFtQjthQUM3QjtZQUNEO2dCQUNFLElBQUksRUFBRSxRQUFRO2dCQUNkLE9BQU8sRUFBRSw0Q0FBNEM7Z0JBQ3JELE9BQU8sRUFBRSxvQkFBb0I7YUFDOUI7WUFDRDtnQkFDRSxJQUFJLEVBQUUsV0FBVztnQkFDakIsT0FBTyxFQUFFLGdFQUFnRTtnQkFDekUsT0FBTyxFQUFFLGdCQUFnQjthQUMxQjtZQUNEO2dCQUNFLElBQUksRUFBRSxVQUFVO2dCQUNoQixPQUFPLEVBQUUsc0NBQXNDO2dCQUMvQyxPQUFPLEVBQUUsc0JBQXNCO2FBQ2hDO1NBQ0YsQ0FBQztRQUVGLE1BQU0sS0FBSyxHQUFzQixFQUFFLENBQUM7UUFFcEMsbURBQW1EO1FBQ25ELE1BQU0sUUFBUSxHQUFHLGdCQUFnQixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDbEUsTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUU3RSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQ2xDLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQztZQUN0QixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsR0FBRyxTQUFTLENBQUM7WUFFaEUsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDVCxFQUFFLEVBQUUsZUFBZSxLQUFLLEVBQUU7Z0JBQzFCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtnQkFDbEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO2dCQUN4QixXQUFXLEVBQUUsT0FBTyxDQUFDLE9BQU87Z0JBQzVCLFdBQVcsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTtnQkFDckMsV0FBVyxFQUFFLFdBQVc7Z0JBQ3hCLGNBQWMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFO2dCQUNuRCxPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87Z0JBQ3hCLFlBQVksRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDN0IsY0FBYyxFQUFFO29CQUNkLE9BQU8sRUFBRSxFQUFFO29CQUNYLE9BQU8sRUFBRSxFQUFFO2lCQUNaO2dCQUNELFlBQVksRUFBRSxJQUFJO2FBQ25CLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDLE1BQU0sMkJBQTJCLENBQUMsQ0FBQztRQUNyRSxPQUFPLEtBQUssQ0FBQztLQUNkO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzVELDJEQUEyRDtRQUMzRCxPQUFPLEVBQUUsQ0FBQztLQUNYO0FBQ0gsQ0FBQztBQUVELEtBQUssVUFBVSx1QkFBdUIsQ0FBQyxLQUFxQjtJQUMxRCxNQUFNLFNBQVMsR0FBYztRQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7UUFDbEIsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHLElBQUksa0JBQWtCO1FBQ3BDLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztRQUNsQixNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUU7UUFDaEIsUUFBUSxFQUFFLEtBQUssQ0FBQyxXQUFXLElBQUksQ0FBQztRQUNoQyxTQUFTLEVBQUUsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUU7UUFDcEQsTUFBTSxFQUFFLGFBQWE7S0FDdEIsQ0FBQztJQUVGLDZDQUE2QztJQUM3QyxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxrQkFBa0IsRUFBRTtRQUNqRCxJQUFJO1lBQ0YsTUFBTSxjQUFjLEdBQUcsTUFBTSxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDNUQsSUFBSSxjQUFjLElBQUksY0FBYyxLQUFLLGlDQUFpQyxFQUFFO2dCQUMxRSxNQUFNLE9BQU8sR0FBRyxNQUFNLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQUM7Z0JBQ3hFLFNBQVMsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO2dCQUU1QixpQ0FBaUM7Z0JBQ2pDLElBQUksT0FBTyxJQUFJLE9BQU8sS0FBSyxxQkFBcUIsRUFBRTtvQkFDaEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxhQUFhLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztvQkFDM0QsU0FBUyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7aUJBQy9CO2FBQ0Y7U0FDRjtRQUFDLE9BQU8sS0FBSyxFQUFFO1lBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3BFLDBEQUEwRDtTQUMzRDtLQUNGO0lBRUQsT0FBTyxTQUFTLENBQUM7QUFDbkIsQ0FBQztBQUVELEtBQUssVUFBVSxzQkFBc0IsQ0FBQyxJQUFxQjtJQUN6RCxNQUFNLFNBQVMsR0FBYztRQUMzQixLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUk7UUFDaEIsR0FBRyxFQUFFLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFlBQVk7UUFDdEMsS0FBSyxFQUFFLElBQUksQ0FBQyxXQUFXO1FBQ3ZCLE1BQU0sRUFBRSxjQUFjO1FBQ3RCLFFBQVEsRUFBRSxJQUFJLENBQUMsY0FBYztRQUM3QixTQUFTLEVBQUUsSUFBSSxDQUFDLFdBQVc7UUFDM0IsTUFBTSxFQUFFLGNBQWM7S0FDdkIsQ0FBQztJQUVGLG1EQUFtRDtJQUNuRCxNQUFNLGNBQWMsR0FBRyxpQkFBaUIsSUFBSSxDQUFDLElBQUksK0NBQStDLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxpREFBaUQsSUFBSSxDQUFDLFdBQVcsMkZBQTJGLENBQUM7SUFFclQsU0FBUyxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUM7SUFFbkMsbURBQW1EO0lBQ25ELElBQUksU0FBUyxDQUFDLE9BQU8sRUFBRTtRQUNyQixNQUFNLFFBQVEsR0FBRyxNQUFNLGFBQWEsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6RSxTQUFTLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztLQUMvQjtJQUVELE9BQU8sU0FBUyxDQUFDO0FBQ25CLENBQUM7QUFFRCxLQUFLLFVBQVUsdUJBQXVCLENBQUMsSUFBc0I7SUFDM0QsTUFBTSxTQUFTLEdBQWM7UUFDM0IsS0FBSyxFQUFFLElBQUksQ0FBQyxTQUFTO1FBQ3JCLEdBQUcsRUFBRSxJQUFJLENBQUMsUUFBUTtRQUNsQixLQUFLLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtRQUM1QixNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLO1FBQ3hCLFFBQVEsRUFBRSxDQUFDO1FBQ1gsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVO1FBQzFCLE1BQU0sRUFBRSxpQkFBaUI7S0FDMUIsQ0FBQztJQUVGLG1EQUFtRDtJQUNuRCxNQUFNLFdBQVcsR0FBRyxpQkFBaUIsSUFBSSxDQUFDLFNBQVMsbUNBQW1DLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGVBQWUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDLFdBQVcsSUFBSSwwQkFBMEIsb0RBQW9ELElBQUksQ0FBQyxnQkFBZ0IscUpBQXFKLENBQUM7SUFFM1osU0FBUyxDQUFDLE9BQU8sR0FBRyxXQUFXLENBQUM7SUFFaEMsbURBQW1EO0lBQ25ELElBQUksU0FBUyxDQUFDLE9BQU8sRUFBRTtRQUNyQixNQUFNLFFBQVEsR0FBRyxNQUFNLGFBQWEsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6RSxTQUFTLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztLQUMvQjtJQUVELE9BQU8sU0FBUyxDQUFDO0FBQ25CLENBQUM7QUFFRCxLQUFLLFVBQVUsbUJBQW1CLENBQUMsR0FBVztJQUM1QyxJQUFJO1FBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUN4RCxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVuQywyRUFBMkU7UUFDM0UsTUFBTSxXQUFXLEdBQUcsT0FBTzthQUN4QixPQUFPLENBQUMscURBQXFELEVBQUUsRUFBRSxDQUFDLENBQUMsaUJBQWlCO2FBQ3BGLE9BQU8sQ0FBQyxrREFBa0QsRUFBRSxFQUFFLENBQUMsQ0FBQyxnQkFBZ0I7YUFDaEYsT0FBTyxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQyxtQkFBbUI7YUFDNUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyx1QkFBdUI7YUFDNUMsSUFBSSxFQUFFLENBQUM7UUFFVixtREFBbUQ7UUFDbkQsTUFBTSxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7UUFFMUcsT0FBTyxnQkFBZ0IsQ0FBQztLQUN6QjtJQUFDLE9BQU8sS0FBSyxFQUFFO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQywwQ0FBMEMsR0FBRyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDdkUsT0FBTyxpQ0FBaUMsQ0FBQztLQUMxQztBQUNILENBQUM7QUFFRCxLQUFLLFVBQVUsb0JBQW9CLENBQUMsS0FBYSxFQUFFLE9BQWU7SUFDaEUsSUFBSTtRQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLEtBQUssRUFBRSxDQUFDLENBQUM7UUFFbkQsTUFBTSxhQUFhLEdBQUcsSUFBSSw2Q0FBb0IsQ0FBQztZQUM3QyxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztTQUM5QyxDQUFDLENBQUM7UUFFSCxNQUFNLE1BQU0sR0FBRzs7Ozs7Ozs7RUFRakIsT0FBTzs7V0FFRSxDQUFDO1FBRVIsTUFBTSxJQUFJLEdBQUc7WUFDWCxpQkFBaUIsRUFBRSxvQkFBb0I7WUFDdkMsVUFBVSxFQUFFLElBQUk7WUFDaEIsUUFBUSxFQUFFO2dCQUNSO29CQUNFLElBQUksRUFBRSxNQUFNO29CQUNaLE9BQU8sRUFBRSxNQUFNO2lCQUNoQjthQUNGO1NBQ0YsQ0FBQztRQUVGLE1BQU0sT0FBTyxHQUFHLElBQUksMkNBQWtCLENBQUM7WUFDckMsT0FBTyxFQUFFLDhDQUE4QztZQUN2RCxXQUFXLEVBQUUsa0JBQWtCO1lBQy9CLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztTQUMzQixDQUFDLENBQUM7UUFFSCxNQUFNLFFBQVEsR0FBRyxNQUFNLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbkQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUV6RSxPQUFPLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0tBQzVDO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzVELE9BQU8scUJBQXFCLENBQUM7S0FDOUI7QUFDSCxDQUFDO0FBRUQsS0FBSyxVQUFVLGFBQWEsQ0FBQyxLQUFhLEVBQUUsT0FBZTtJQUN6RCxJQUFJO1FBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUVqRCxNQUFNLFdBQVcsR0FBRyxJQUFJLDBCQUFXLENBQUM7WUFDbEMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLFdBQVc7U0FDOUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxRQUFRLEdBQUcsSUFBSSxvQkFBUSxDQUFDO1lBQzVCLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsSUFBSSxXQUFXO1NBQzlDLENBQUMsQ0FBQztRQUVILGtDQUFrQztRQUNsQyxNQUFNLFVBQVUsR0FBRyxPQUFPO2FBQ3ZCLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUMsMEJBQTBCO2FBQ2xELE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQyx5QkFBeUI7YUFDekQsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQywyQkFBMkI7YUFDdkQsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxrQ0FBa0M7YUFDdkQsSUFBSSxFQUFFLENBQUM7UUFFViw2QkFBNkI7UUFDN0IsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLHNDQUF1QixDQUFDO1lBQ3BELElBQUksRUFBRSxVQUFVO1lBQ2hCLFlBQVksRUFBRSxLQUFLO1lBQ25CLE9BQU8sRUFBRSxRQUFRO1lBQ2pCLE1BQU0sRUFBRSxRQUFRO1NBQ2pCLENBQUMsQ0FBQztRQUVILE1BQU0sYUFBYSxHQUFHLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBRWhFLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFO1lBQzlCLE1BQU0sSUFBSSxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQztTQUN4RDtRQUVELGlDQUFpQztRQUNqQyxNQUFNLFdBQVcsR0FBRyxNQUFNLGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFcEUsMkJBQTJCO1FBQzNCLE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN4RCxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQy9FLE1BQU0sUUFBUSxHQUFHLFNBQVMsU0FBUyxJQUFJLFNBQVMsTUFBTSxDQUFDO1FBRXZELGVBQWU7UUFDZixNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO1FBQ2pELElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDZixNQUFNLElBQUksS0FBSyxDQUFDLGdEQUFnRCxDQUFDLENBQUM7U0FDbkU7UUFFRCxNQUFNLGFBQWEsR0FBRyxJQUFJLDRCQUFnQixDQUFDO1lBQ3pDLE1BQU0sRUFBRSxVQUFVO1lBQ2xCLEdBQUcsRUFBRSxRQUFRO1lBQ2IsSUFBSSxFQUFFLFdBQVc7WUFDakIsV0FBVyxFQUFFLFlBQVk7U0FDMUIsQ0FBQyxDQUFDO1FBRUgsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRW5DLE1BQU0sUUFBUSxHQUFHLFdBQVcsVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLFdBQVcsa0JBQWtCLFFBQVEsRUFBRSxDQUFDO1FBQy9HLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFFL0MsT0FBTyxRQUFRLENBQUM7S0FDakI7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsNkJBQTZCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDcEQsT0FBTyxTQUFTLENBQUM7S0FDbEI7QUFDSCxDQUFDO0FBRUQsS0FBSyxVQUFVLHFCQUFxQixDQUFDLE9BQW9CLEVBQUUsU0FBaUI7SUFDMUUsSUFBSTtRQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLE9BQU8sQ0FBQyxNQUFNLFVBQVUsQ0FBQyxDQUFDO1FBRTFFLE1BQU0sV0FBVyxHQUFHLElBQUksMEJBQVcsQ0FBQztZQUNsQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztTQUM5QyxDQUFDLENBQUM7UUFFSCxNQUFNLFFBQVEsR0FBRyxJQUFJLG9CQUFRLENBQUM7WUFDNUIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLFdBQVc7U0FDOUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxZQUFZLEdBQWEsRUFBRSxDQUFDO1FBRWxDLGlCQUFpQjtRQUNqQixPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUM7UUFDNUMsTUFBTSxTQUFTLEdBQUcscUdBQXFHLENBQUM7UUFDeEgsTUFBTSxXQUFXLEdBQUcsTUFBTSx5QkFBeUIsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDNUUsSUFBSSxXQUFXO1lBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUVoRCw2Q0FBNkM7UUFDN0MsS0FBSyxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7WUFDbkQsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdCLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtnQkFDakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsS0FBSyxHQUFHLENBQUMsS0FBSyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztnQkFFMUUsNEJBQTRCO2dCQUM1QixNQUFNLFNBQVMsR0FBRyxTQUFTLEtBQUssR0FBRyxDQUFDLEtBQUssS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDO2dCQUN4RCxNQUFNLFdBQVcsR0FBRyxNQUFNLHlCQUF5QixDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDNUUsSUFBSSxXQUFXO29CQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBRWhELDJEQUEyRDtnQkFDM0QsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLE9BQU87cUJBQy9CLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUMsMEJBQTBCO3FCQUNsRCxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQUMseUJBQXlCO3FCQUN6RCxPQUFPLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLDJCQUEyQjtxQkFDdkQsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxrQ0FBa0M7cUJBQ3ZELElBQUksRUFBRSxDQUFDO2dCQUVWLHlFQUF5RTtnQkFDekUsTUFBTSxhQUFhLEdBQUcsbUJBQW1CLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUU5RCwrQ0FBK0M7Z0JBQy9DLEtBQUssTUFBTSxLQUFLLElBQUksYUFBYSxFQUFFO29CQUNqQyxNQUFNLFdBQVcsR0FBRyxNQUFNLHlCQUF5QixDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDeEUsSUFBSSxXQUFXO3dCQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ2pEO2dCQUVELG9DQUFvQztnQkFDcEMsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQzlCLE1BQU0sV0FBVyxHQUFHLE1BQU0seUJBQXlCLENBQUMsV0FBVyxFQUFFLGFBQWEsQ0FBQyxDQUFDO29CQUNoRixJQUFJLFdBQVc7d0JBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDakQ7YUFDRjtTQUNGO1FBRUQsaUJBQWlCO1FBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztRQUM1QyxNQUFNLFNBQVMsR0FBRyxxRUFBcUUsQ0FBQztRQUN4RixNQUFNLFdBQVcsR0FBRyxNQUFNLHlCQUF5QixDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUM1RSxJQUFJLFdBQVc7WUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRWhELElBQUksWUFBWSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDN0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1NBQ3BEO1FBRUQsZ0NBQWdDO1FBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLFlBQVksQ0FBQyxNQUFNLG9CQUFvQixDQUFDLENBQUM7UUFDekUsTUFBTSxjQUFjLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUVuRCw4Q0FBOEM7UUFDOUMsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3hELE1BQU0sUUFBUSxHQUFHLFNBQVMsU0FBUyxpQkFBaUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUM7UUFFckUsZUFBZTtRQUNmLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7UUFDakQsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0RBQWdELENBQUMsQ0FBQztTQUNuRTtRQUVELE1BQU0sYUFBYSxHQUFHLElBQUksNEJBQWdCLENBQUM7WUFDekMsTUFBTSxFQUFFLFVBQVU7WUFDbEIsR0FBRyxFQUFFLFFBQVE7WUFDYixJQUFJLEVBQUUsY0FBYztZQUNwQixXQUFXLEVBQUUsWUFBWTtTQUMxQixDQUFDLENBQUM7UUFFSCxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFbkMsTUFBTSxRQUFRLEdBQUcsV0FBVyxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVyxrQkFBa0IsUUFBUSxFQUFFLENBQUM7UUFDL0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUV4RCxPQUFPLFFBQVEsQ0FBQztLQUNqQjtJQUFDLE9BQU8sS0FBSyxFQUFFO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyxzQ0FBc0MsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM3RCxPQUFPLFNBQVMsQ0FBQztLQUNsQjtBQUNILENBQUM7QUFFRCxTQUFTLG1CQUFtQixDQUFDLElBQVksRUFBRSxZQUFvQjtJQUM3RCxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksWUFBWSxFQUFFO1FBQy9CLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUNmO0lBRUQsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO0lBQzVCLElBQUksWUFBWSxHQUFHLEVBQUUsQ0FBQztJQUV0QixnREFBZ0Q7SUFDaEQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBRXhFLEtBQUssTUFBTSxRQUFRLElBQUksU0FBUyxFQUFFO1FBQ2hDLE1BQU0sZUFBZSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN4QyxJQUFJLENBQUMsZUFBZTtZQUFFLFNBQVM7UUFFL0IsTUFBTSx1QkFBdUIsR0FBRyxlQUFlLEdBQUcsR0FBRyxDQUFDO1FBRXRELHVGQUF1RjtRQUN2RixJQUFJLFlBQVksQ0FBQyxNQUFNLEdBQUcsdUJBQXVCLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxZQUFZLEVBQUU7WUFDM0UsSUFBSSxZQUFZLENBQUMsSUFBSSxFQUFFLEVBQUU7Z0JBQ3ZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7YUFDbEM7WUFDRCxZQUFZLEdBQUcsdUJBQXVCLENBQUM7U0FDeEM7YUFBTTtZQUNMLFlBQVksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyx1QkFBdUIsQ0FBQztTQUNyRTtLQUNGO0lBRUQsdUNBQXVDO0lBQ3ZDLElBQUksWUFBWSxDQUFDLElBQUksRUFBRSxFQUFFO1FBQ3ZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7S0FDbEM7SUFFRCxPQUFPLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxpREFBaUQ7QUFDL0YsQ0FBQztBQUVELEtBQUssVUFBVSx5QkFBeUIsQ0FBQyxXQUF3QixFQUFFLElBQVk7SUFDN0UsSUFBSTtRQUNGLHlEQUF5RDtRQUN6RCxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFbEYsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLHNDQUF1QixDQUFDO1lBQ3BELElBQUksRUFBRSxhQUFhO1lBQ25CLFlBQVksRUFBRSxLQUFLO1lBQ25CLE9BQU8sRUFBRSxRQUFRO1lBQ2pCLE1BQU0sRUFBRSxRQUFRO1NBQ2pCLENBQUMsQ0FBQztRQUVILE1BQU0sYUFBYSxHQUFHLE1BQU0sV0FBVyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBRWhFLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFO1lBQzlCLE9BQU8sQ0FBQyxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQztZQUNyRCxPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsT0FBTyxNQUFNLGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7S0FDeEQ7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkNBQTJDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDbEUsT0FBTyxJQUFJLENBQUM7S0FDYjtBQUNILENBQUM7QUFFRCxLQUFLLFVBQVUsY0FBYyxDQUFDLE1BQVc7SUFDdkMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtRQUNyQyxNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7UUFFNUIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFhLEVBQUUsRUFBRTtZQUNsQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDO1FBRUgsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFO1lBQ3BCLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQVksRUFBRSxFQUFFO1lBQ2xDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVELEtBQUssVUFBVSx3QkFBd0IsQ0FDckMsT0FBb0IsRUFDcEIsU0FBaUIsRUFDakIsZ0JBQXlCO0lBRXpCLE1BQU0sWUFBWSxHQUFHLElBQUksZ0NBQWMsQ0FBQztRQUN0QyxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztLQUM5QyxDQUFDLENBQUM7SUFFSCxNQUFNLFNBQVMsR0FBRyxxQ0FBc0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDNUQsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQztJQUV6RCxJQUFJLENBQUMsU0FBUyxFQUFFO1FBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO0tBQzVFO0lBRUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CO0lBQ2xGLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7SUFFOUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLE9BQU8sQ0FBQyxNQUFNLDhCQUE4QixJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBRTdFLHdDQUF3QztJQUN4QyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNqRCxVQUFVLEVBQUU7WUFDVixJQUFJLEVBQUU7Z0JBQ0osRUFBRSxFQUFFLEdBQUcsS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO2dCQUM1QyxJQUFJLEVBQUUsSUFBSTtnQkFDVixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07Z0JBQ3BCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztnQkFDbEIsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHO2dCQUNkLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztnQkFDbEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO2dCQUNwQixRQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7Z0JBQ3hCLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUztnQkFDMUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPLElBQUksRUFBRTtnQkFDNUIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksRUFBRTtnQkFDOUIsR0FBRyxFQUFFLGNBQWM7YUFDRztTQUN6QjtLQUNGLENBQUMsQ0FBQyxDQUFDO0lBRUosNkJBQTZCO0lBQzdCLE1BQU0sWUFBWSxHQUFnQjtRQUNoQyxFQUFFLEVBQUUsVUFBVSxJQUFJLEVBQUU7UUFDcEIsSUFBSSxFQUFFLElBQUk7UUFDVixNQUFNLEVBQUUsY0FBYztRQUN0QixZQUFZLEVBQUUsT0FBTyxDQUFDLE1BQU07UUFDNUIsU0FBUyxFQUFFLFNBQVM7UUFDcEIsZ0JBQWdCLEVBQUUsZ0JBQWdCLElBQUksRUFBRTtRQUN4QyxTQUFTLEVBQUUsS0FBSztRQUNoQixHQUFHLEVBQUUsY0FBYztLQUNwQixDQUFDO0lBRUYsSUFBSTtRQUNGLGtFQUFrRTtRQUNsRSxNQUFNLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDbkIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRTtZQUMvQyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQzVDO1FBRUQsS0FBSyxNQUFNLEtBQUssSUFBSSxPQUFPLEVBQUU7WUFDM0IsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLGdDQUFpQixDQUFDO2dCQUM5QyxZQUFZLEVBQUU7b0JBQ1osQ0FBQyxTQUFTLENBQUMsRUFBRSxLQUFLO2lCQUNuQjthQUNGLENBQUMsQ0FBQztZQUNILE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1NBQ3pDO1FBRUQscUJBQXFCO1FBQ3JCLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSx5QkFBVSxDQUFDO1lBQ3RDLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLElBQUksRUFBRSxZQUFZO1NBQ25CLENBQUMsQ0FBQztRQUNILE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXZDLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLE9BQU8sQ0FBQyxNQUFNLG1DQUFtQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0tBQzlGO0lBQUMsT0FBTyxLQUFLLEVBQUU7UUFDZCxPQUFPLENBQUMsS0FBSyxDQUFDLCtDQUErQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3RFLE1BQU0sS0FBSyxDQUFDO0tBQ2I7QUFDSCxDQUFDO0FBRUQsS0FBSyxVQUFVLHFCQUFxQixDQUFDLFNBQWlCO0lBQ3BELE1BQU0sWUFBWSxHQUFHLElBQUksZ0NBQWMsQ0FBQztRQUN0QyxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztLQUM5QyxDQUFDLENBQUM7SUFFSCxNQUFNLFNBQVMsR0FBRyxxQ0FBc0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDNUQsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQztJQUV6RCxJQUFJLENBQUMsU0FBUyxFQUFFO1FBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO0tBQzVFO0lBRUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRTdELElBQUk7UUFDRixNQUFNLFVBQVUsR0FBRyxJQUFJLHlCQUFVLENBQUM7WUFDaEMsU0FBUyxFQUFFLFNBQVM7WUFDcEIsSUFBSSxFQUFFO2dCQUNKLEVBQUUsRUFBRSxVQUFVLElBQUksRUFBRTtnQkFDcEIsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsV0FBVyxFQUFFLFNBQVM7YUFDdkI7WUFDRCxtQkFBbUIsRUFBRSx1QkFBdUI7WUFDNUMsd0JBQXdCLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxJQUFJO2FBQ1o7U0FDRixDQUFDLENBQUM7UUFFSCxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDakMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsSUFBSSxFQUFFLENBQUMsQ0FBQztLQUN4RDtJQUFDLE9BQU8sS0FBSyxFQUFFO1FBQ2QsT0FBTyxDQUFDLEtBQUssQ0FBQyx1Q0FBdUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM5RCw4Q0FBOEM7S0FDL0M7QUFDSCxDQUFDO0FBRUQsS0FBSyxVQUFVLGdCQUFnQixDQUFDLGNBQThCLEVBQUUsU0FBaUI7SUFDL0UsTUFBTSxTQUFTLEdBQUcsSUFBSSxzQkFBUyxDQUFDO1FBQzlCLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsSUFBSSxXQUFXO0tBQzlDLENBQUMsQ0FBQztJQUVILDRCQUE0QjtJQUM1QixNQUFNLFdBQVcsR0FBRyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDakUsTUFBTSxXQUFXLEdBQUcsaUJBQWlCLENBQUMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBRWpFLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFO1lBQ1gsV0FBVyxFQUFFLENBQUMsbUJBQW1CLENBQUM7U0FDbkM7UUFDRCxPQUFPLEVBQUU7WUFDUCxJQUFJLEVBQUU7Z0JBQ0osSUFBSSxFQUFFO29CQUNKLE9BQU8sRUFBRSxPQUFPO29CQUNoQixJQUFJLEVBQUUsV0FBVztpQkFDbEI7Z0JBQ0QsSUFBSSxFQUFFO29CQUNKLE9BQU8sRUFBRSxPQUFPO29CQUNoQixJQUFJLEVBQUUsV0FBVztpQkFDbEI7YUFDRjtZQUNELE9BQU8sRUFBRTtnQkFDUCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsSUFBSSxFQUFFLDRCQUE0QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxFQUFFO2FBQzdFO1NBQ0Y7UUFDRCxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLElBQUksdUJBQXVCLENBQUMsMENBQTBDO0tBQ3pHLENBQUM7SUFFRixNQUFNLE9BQU8sR0FBRyxJQUFJLDZCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQzdDLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUU5Qix5Q0FBeUM7SUFDekMsSUFBSTtRQUNGLE1BQU0scUJBQXFCLENBQUMsU0FBUyxDQUFDLENBQUM7S0FDeEM7SUFBQyxPQUFPLEtBQUssRUFBRTtRQUNkLE9BQU8sQ0FBQyxLQUFLLENBQUMsbURBQW1ELEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDMUUscUNBQXFDO0tBQ3RDO0FBQ0gsQ0FBQztBQUVELFNBQVMsaUJBQWlCLENBQUMsY0FBOEIsRUFBRSxTQUFpQjtJQUMxRSxNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUU7UUFDM0QsT0FBTyxFQUFFLE1BQU07UUFDZixJQUFJLEVBQUUsU0FBUztRQUNmLEtBQUssRUFBRSxNQUFNO1FBQ2IsR0FBRyxFQUFFLFNBQVM7UUFDZCxJQUFJLEVBQUUsU0FBUztRQUNmLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLFlBQVksRUFBRSxPQUFPO0tBQ3RCLENBQUMsQ0FBQztJQUVILHVEQUF1RDtJQUN2RCxJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7SUFDeEIsSUFBSSxjQUFjLENBQUMsZ0JBQWdCLEVBQUU7UUFDbkMsY0FBYyxHQUFHOzs7bUJBR0YsY0FBYyxDQUFDLGdCQUFnQjs7O3FGQUdtQyxjQUFjLENBQUMsT0FBTyxDQUFDLE1BQU07YUFDckcsQ0FBQztLQUNYO0lBRUQsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLGNBQWMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFO1FBQzVDLElBQUksVUFBVSxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUM7UUFDeEMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLGFBQWEsRUFBRTtZQUNsQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ2xCLFdBQVcsR0FBRyxTQUFTLENBQUM7WUFDeEIsVUFBVSxHQUFHLGFBQWEsQ0FBQztTQUM1QjthQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxjQUFjLEVBQUU7WUFDMUMsVUFBVSxHQUFHLElBQUksQ0FBQztZQUNsQixXQUFXLEdBQUcsU0FBUyxDQUFDO1lBQ3hCLFVBQVUsR0FBRyxjQUFjLENBQUM7U0FDN0I7YUFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssaUJBQWlCLEVBQUU7WUFDN0MsVUFBVSxHQUFHLEdBQUcsQ0FBQztZQUNqQixXQUFXLEdBQUcsU0FBUyxDQUFDO1lBQ3hCLFVBQVUsR0FBRyxpQkFBaUIsQ0FBQztTQUNoQztRQUVILFdBQVcsSUFBSTs0R0FDeUYsV0FBVzs7NkNBRTFFLFdBQVc7Z0JBQ3hDLFVBQVUsSUFBSSxVQUFVOzs7O2NBSTFCLEtBQUssR0FBRyxDQUFDLGNBQWMsS0FBSyxDQUFDLEdBQUcsbUJBQW1CLFdBQVcsNkJBQTZCLEtBQUssQ0FBQyxLQUFLOzs7dUJBRzdGLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLEVBQUU7ZUFDbEQsQ0FBQztRQUVaLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtZQUNqQixnREFBZ0Q7WUFDaEQsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLE9BQU87aUJBQzlCLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUMsNkNBQTZDO2lCQUNyRSxPQUFPLENBQUMsZ0JBQWdCLEVBQUUscUJBQXFCLENBQUM7aUJBQ2hELE9BQU8sQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDO2lCQUNwQyxPQUFPLENBQUMsZUFBZSxFQUFFLDZFQUE2RSxDQUFDO2lCQUN2RyxPQUFPLENBQUMsT0FBTyxFQUFFLGtEQUFrRCxDQUFDO2lCQUNwRSxPQUFPLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRTFCLFdBQVcsSUFBSTs7OzBEQUdxQyxXQUFXO2lCQUNwRCxDQUFDO1lBR1osV0FBVyxJQUFJO2VBQ04sQ0FBQztTQUNYO1FBRUQsV0FBVyxJQUFJOztLQUVkLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUVILE9BQU87Ozs7Ozs7Ozs7OzZEQVdvRCxJQUFJOzs7VUFHdkQsY0FBYzs7O2lEQUd5QixjQUFjLENBQUMsT0FBTyxDQUFDLE1BQU07Y0FDaEUsV0FBVzs7Ozs7Ozs7O0dBU3RCLENBQUM7QUFDSixDQUFDO0FBRUQsU0FBUyxpQkFBaUIsQ0FBQyxjQUE4QixFQUFFLFNBQWlCO0lBQzFFLE1BQU0sSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRTtRQUMzRCxPQUFPLEVBQUUsTUFBTTtRQUNmLElBQUksRUFBRSxTQUFTO1FBQ2YsS0FBSyxFQUFFLE1BQU07UUFDYixHQUFHLEVBQUUsU0FBUztRQUNkLElBQUksRUFBRSxTQUFTO1FBQ2YsTUFBTSxFQUFFLFNBQVM7UUFDakIsWUFBWSxFQUFFLE9BQU87S0FDdEIsQ0FBQyxDQUFDO0lBRUgsdURBQXVEO0lBQ3ZELElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztJQUNyQixJQUFJLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBRTtRQUNuQyxXQUFXLEdBQUc7OzBCQUVRLGNBQWMsQ0FBQyxnQkFBZ0I7Z0JBQ3pDLGNBQWMsQ0FBQyxPQUFPLENBQUMsTUFBTTs7OztDQUk1QyxDQUFDO0tBQ0M7SUFFRCxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7SUFDckIsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUU7UUFDOUMsSUFBSSxXQUFXLENBQUM7UUFDaEIsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLGFBQWEsRUFBRTtZQUNsQyxXQUFXLEdBQUcsZ0JBQWdCLENBQUM7U0FDaEM7YUFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssY0FBYyxFQUFFO1lBQzFDLFdBQVcsR0FBRyxpQkFBaUIsQ0FBQztTQUNqQzthQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxpQkFBaUIsRUFBRTtZQUM3QyxXQUFXLEdBQUcsbUJBQW1CLENBQUM7U0FDbkM7UUFDRCxXQUFXLElBQUk7RUFDakIsS0FBSyxHQUFHLENBQUMsS0FBSyxLQUFLLENBQUMsS0FBSyxLQUFLLFdBQVc7VUFDakMsS0FBSyxDQUFDLEdBQUc7YUFDTixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQztRQUV0RCxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7WUFDakIseUNBQXlDO1lBQ3pDLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxPQUFPO2lCQUMvQixPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFDLDhCQUE4QjtpQkFDdEQsT0FBTyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQztpQkFDL0IsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUM7aUJBQzNCLE9BQU8sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFakMsV0FBVyxJQUFJOztFQUVuQixZQUFZLEVBQUUsQ0FBQztTQUNaO1FBRUQsV0FBVyxJQUFJOztDQUVsQixDQUFDO0lBQ0EsQ0FBQyxDQUFDLENBQUM7SUFFSCxPQUFPOzs7O0VBSVAsSUFBSTs7RUFFSixXQUFXLE9BQU8sY0FBYyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0VBQy9DLFdBQVc7Ozs7R0FJVixDQUFDO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFQSUdhdGV3YXlQcm94eUV2ZW50LCBBUElHYXRld2F5UHJveHlSZXN1bHQsIENvbnRleHQgfSBmcm9tICdhd3MtbGFtYmRhJztcbmltcG9ydCAqIGFzIGh0dHBzIGZyb20gJ2h0dHBzJztcbmltcG9ydCB7IFNFU0NsaWVudCwgU2VuZEVtYWlsQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1zZXMnO1xuaW1wb3J0IHsgQmVkcm9ja1J1bnRpbWVDbGllbnQsIEludm9rZU1vZGVsQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1iZWRyb2NrLXJ1bnRpbWUnO1xuaW1wb3J0IHsgUG9sbHlDbGllbnQsIFN5bnRoZXNpemVTcGVlY2hDb21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LXBvbGx5JztcbmltcG9ydCB7IFMzQ2xpZW50LCBQdXRPYmplY3RDb21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LXMzJztcbmltcG9ydCB7IER5bmFtb0RCQ2xpZW50IH0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LWR5bmFtb2RiJztcbmltcG9ydCB7IER5bmFtb0RCRG9jdW1lbnRDbGllbnQsIFB1dENvbW1hbmQsIEJhdGNoV3JpdGVDb21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvbGliLWR5bmFtb2RiJztcblxuaW50ZXJmYWNlIEhhY2tlck5ld3NJdGVtIHtcbiAgaWQ6IG51bWJlcjtcbiAgdGl0bGU6IHN0cmluZztcbiAgdXJsPzogc3RyaW5nO1xuICBzY29yZTogbnVtYmVyO1xuICBieTogc3RyaW5nO1xuICB0aW1lOiBudW1iZXI7XG4gIGRlc2NlbmRhbnRzPzogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgUHJvZHVjdEh1bnRQb3N0IHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICB0YWdsaW5lOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIGZlYXR1cmVkX2F0OiBzdHJpbmc7XG4gIHZvdGVzX2NvdW50OiBudW1iZXI7XG4gIGNvbW1lbnRzX2NvdW50OiBudW1iZXI7XG4gIHdlYnNpdGU6IHN0cmluZztcbiAgcmVkaXJlY3RfdXJsOiBzdHJpbmc7XG4gIHNjcmVlbnNob3RfdXJsOiB7XG4gICAgXCIzMDBweFwiOiBzdHJpbmc7XG4gICAgXCI4NTBweFwiOiBzdHJpbmc7XG4gIH07XG4gIG1ha2VyX2luc2lkZTogYm9vbGVhbjtcbn1cblxuaW50ZXJmYWNlIEdpdEh1YlJlcG9zaXRvcnkge1xuICBpZDogbnVtYmVyO1xuICBuYW1lOiBzdHJpbmc7XG4gIGZ1bGxfbmFtZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICBodG1sX3VybDogc3RyaW5nO1xuICBzdGFyZ2F6ZXJzX2NvdW50OiBudW1iZXI7XG4gIGxhbmd1YWdlOiBzdHJpbmc7XG4gIGNyZWF0ZWRfYXQ6IHN0cmluZztcbiAgdXBkYXRlZF9hdDogc3RyaW5nO1xuICBvd25lcjoge1xuICAgIGxvZ2luOiBzdHJpbmc7XG4gICAgYXZhdGFyX3VybDogc3RyaW5nO1xuICB9O1xufVxuXG5pbnRlcmZhY2UgU3RvcnlJbmZvIHtcbiAgdGl0bGU6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG4gIHNjb3JlOiBudW1iZXI7XG4gIGF1dGhvcjogc3RyaW5nO1xuICBjb21tZW50czogbnVtYmVyO1xuICB0aW1lc3RhbXA6IHN0cmluZztcbiAgc291cmNlOiAnaGFja2VyLW5ld3MnIHwgJ3Byb2R1Y3QtaHVudCcgfCAnZ2l0aHViLXRyZW5kaW5nJztcbiAgc3VtbWFyeT86IHN0cmluZztcbiAgYXVkaW9Vcmw/OiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBOZXdzbGV0dGVyRGF0YSB7XG4gIHN0b3JpZXM6IFN0b3J5SW5mb1tdO1xuICBjb21iaW5lZEF1ZGlvVXJsPzogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgRGFpbHlSZWNvbW1lbmRhdGlvbiB7XG4gIGlkOiBzdHJpbmc7IC8vIHVuaXF1ZSBpZGVudGlmaWVyIGZvciBlYWNoIHN0b3J5IChwYXJ0aXRpb24ga2V5KVxuICBkYXRlOiBzdHJpbmc7IC8vIFlZWVktTU0tREQgZm9ybWF0IFxuICBzb3VyY2U6ICdoYWNrZXItbmV3cycgfCAncHJvZHVjdC1odW50JyB8ICdnaXRodWItdHJlbmRpbmcnO1xuICB0aXRsZTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgc2NvcmU6IG51bWJlcjtcbiAgYXV0aG9yOiBzdHJpbmc7XG4gIGNvbW1lbnRzOiBudW1iZXI7XG4gIHRpbWVzdGFtcDogc3RyaW5nOyAvLyBJU08gc3RyaW5nXG4gIHN1bW1hcnk/OiBzdHJpbmc7XG4gIGF1ZGlvVXJsPzogc3RyaW5nO1xuICB0dGw6IG51bWJlcjsgLy8gVW5peCB0aW1lc3RhbXAgZm9yIGF1dG9tYXRpYyBkZWxldGlvbiBhZnRlciAzNjUgZGF5c1xufVxuXG5pbnRlcmZhY2UgRGFpbHlEaWdlc3Qge1xuICBpZDogc3RyaW5nOyAvLyAnZGlnZXN0LVlZWVktTU0tREQnIChwYXJ0aXRpb24ga2V5KVxuICBkYXRlOiBzdHJpbmc7IC8vIFlZWVktTU0tREQgZm9ybWF0XG4gIHNvdXJjZTogJ2RhaWx5LWRpZ2VzdCc7XG4gIHRvdGFsU3RvcmllczogbnVtYmVyO1xuICB0aW1lc3RhbXA6IHN0cmluZzsgLy8gSVNPIHN0cmluZ1xuICBjb21iaW5lZEF1ZGlvVXJsPzogc3RyaW5nO1xuICBlbWFpbFNlbnQ6IGJvb2xlYW47XG4gIHR0bDogbnVtYmVyOyAvLyBVbml4IHRpbWVzdGFtcCBmb3IgYXV0b21hdGljIGRlbGV0aW9uIGFmdGVyIDM2NSBkYXlzXG59XG5cbmV4cG9ydCBjb25zdCBoYW5kbGVyID0gYXN5bmMgKFxuICBldmVudDogQVBJR2F0ZXdheVByb3h5RXZlbnQgfCBhbnksXG4gIGNvbnRleHQ6IENvbnRleHRcbik6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0IHwgYW55PiA9PiB7XG4gIGNvbnNvbGUubG9nKCfwn6SWIE5ld3NBZ2VudCBMYW1iZGEgZnVuY3Rpb24gc3RhcnRlZCEnKTtcbiAgY29uc29sZS5sb2coJ0V2ZW50IHNvdXJjZTonLCBldmVudC5zb3VyY2UgfHwgJ2RpcmVjdC1pbnZvY2F0aW9uJyk7XG5cbiAgY29uc3QgY3VycmVudFRpbWUgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIFxuICB0cnkge1xuICAgIC8vIEZldGNoIGNvbnRlbnQgZnJvbSBtdWx0aXBsZSBzb3VyY2VzXG4gICAgY29uc29sZS5sb2coJ/Cfk7AgRmV0Y2hpbmcgdG9wIHN0b3JpZXMgZnJvbSBIYWNrZXIgTmV3cy4uLicpO1xuICAgIGNvbnN0IHRvcFN0b3JpZXMgPSBhd2FpdCBnZXRUb3BIYWNrZXJOZXdzU3RvcmllcygzKTsgLy8gR2V0IHRvcCAzIHN0b3JpZXNcbiAgICBcbiAgICBjb25zb2xlLmxvZygn8J+PhiBGZXRjaGluZyB0b3AgcHJvZHVjdHMgZnJvbSBQcm9kdWN0IEh1bnQuLi4nKTtcbiAgICBjb25zdCB0b3BQcm9kdWN0cyA9IGF3YWl0IGdldFRvcFByb2R1Y3RIdW50UG9zdHMoMyk7IC8vIEdldCB0b3AgMyBwcm9kdWN0c1xuICAgIFxuICAgIGNvbnNvbGUubG9nKCfirZAgRmV0Y2hpbmcgdHJlbmRpbmcgR2l0SHViIHJlcG9zaXRvcmllcy4uLicpO1xuICAgIGNvbnN0IHRyZW5kaW5nUmVwb3MgPSBhd2FpdCBnZXRUb3BHaXRIdWJUcmVuZGluZygzKTsgLy8gR2V0IHRvcCAzIHJlcG9zXG4gICAgXG4gICAgY29uc29sZS5sb2coYPCfk4ogRm91bmQgJHt0b3BTdG9yaWVzLmxlbmd0aH0gSGFja2VyIE5ld3Mgc3RvcmllcywgJHt0b3BQcm9kdWN0cy5sZW5ndGh9IFByb2R1Y3QgSHVudCBwb3N0cywgYW5kICR7dHJlbmRpbmdSZXBvcy5sZW5ndGh9IEdpdEh1YiByZXBvc2l0b3JpZXNgKTtcbiAgICBcbiAgICAvLyBQcm9jZXNzIGVhY2ggc3RvcnkvcHJvZHVjdCB0byBnZXQgYmFzaWMgaW5mbyBhbmQgc3VtbWFyaWVzXG4gICAgY29uc3Qgc3RvcmllczogU3RvcnlJbmZvW10gPSBbXTtcbiAgICBcbiAgICAvLyBQcm9jZXNzIEhhY2tlciBOZXdzIHN0b3JpZXNcbiAgICBmb3IgKGNvbnN0IHN0b3J5IG9mIHRvcFN0b3JpZXMpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0b3J5SW5mbyA9IGF3YWl0IHByb2Nlc3NTdG9yeVdpdGhTdW1tYXJ5KHN0b3J5KTtcbiAgICAgICAgc3Rvcmllcy5wdXNoKHN0b3J5SW5mbyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGDinIUgUHJvY2Vzc2VkIEhOOiBcIiR7c3RvcnlJbmZvLnRpdGxlfVwiICgke3N0b3J5SW5mby5zY29yZX0gcG9pbnRzLCAke3N0b3J5SW5mby5jb21tZW50c30gY29tbWVudHMpYCk7XG4gICAgICAgIGlmIChzdG9yeUluZm8uc3VtbWFyeSkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGDwn5OdIFN1bW1hcnk6ICR7c3RvcnlJbmZvLnN1bW1hcnl9YCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGDinYwgRmFpbGVkIHRvIHByb2Nlc3MgSE4gc3Rvcnk6ICR7c3RvcnkudGl0bGV9YCwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgICBcbiAgICAvLyBQcm9jZXNzIFByb2R1Y3QgSHVudCBwb3N0c1xuICAgIGZvciAoY29uc3QgcHJvZHVjdCBvZiB0b3BQcm9kdWN0cykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcHJvZHVjdEluZm8gPSBhd2FpdCBwcm9jZXNzUHJvZHVjdEh1bnRQb3N0KHByb2R1Y3QpO1xuICAgICAgICBzdG9yaWVzLnB1c2gocHJvZHVjdEluZm8pO1xuICAgICAgICBjb25zb2xlLmxvZyhg4pyFIFByb2Nlc3NlZCBQSDogXCIke3Byb2R1Y3RJbmZvLnRpdGxlfVwiICgke3Byb2R1Y3RJbmZvLnNjb3JlfSB2b3RlcywgJHtwcm9kdWN0SW5mby5jb21tZW50c30gY29tbWVudHMpYCk7XG4gICAgICAgIGlmIChwcm9kdWN0SW5mby5zdW1tYXJ5KSB7XG4gICAgICAgICAgY29uc29sZS5sb2coYPCfk50gU3VtbWFyeTogJHtwcm9kdWN0SW5mby5zdW1tYXJ5fWApO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmxvZyhg4p2MIEZhaWxlZCB0byBwcm9jZXNzIFBIIHByb2R1Y3Q6ICR7cHJvZHVjdC5uYW1lfWAsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgLy8gUHJvY2VzcyBHaXRIdWIgdHJlbmRpbmcgcmVwb3NpdG9yaWVzXG4gICAgZm9yIChjb25zdCByZXBvIG9mIHRyZW5kaW5nUmVwb3MpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcG9JbmZvID0gYXdhaXQgcHJvY2Vzc0dpdEh1YlJlcG9zaXRvcnkocmVwbyk7XG4gICAgICAgIHN0b3JpZXMucHVzaChyZXBvSW5mbyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGDinIUgUHJvY2Vzc2VkIEdpdEh1YjogXCIke3JlcG9JbmZvLnRpdGxlfVwiICgke3JlcG9JbmZvLnNjb3JlfSBzdGFycywgJHtyZXBvSW5mby5jb21tZW50c30gaXNzdWVzKWApO1xuICAgICAgICBpZiAocmVwb0luZm8uc3VtbWFyeSkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGDwn5OdIFN1bW1hcnk6ICR7cmVwb0luZm8uc3VtbWFyeX1gKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coYOKdjCBGYWlsZWQgdG8gcHJvY2VzcyBHaXRIdWIgcmVwbzogJHtyZXBvLmZ1bGxfbmFtZX1gLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gTG9nIGNvbXByZWhlbnNpdmUgc3VtbWFyeVxuICAgIGNvbnNvbGUubG9nKCdcXG49PT0g8J+TiCBIQUNLRVIgTkVXUyBUT1AgU1RPUklFUyA9PT0nKTtcbiAgICBjb25zb2xlLmxvZyhg8J+ThSBHZW5lcmF0ZWQgYXQ6ICR7Y3VycmVudFRpbWV9YCk7XG4gICAgY29uc29sZS5sb2coYPCfk4ogVG90YWwgc3RvcmllcyBwcm9jZXNzZWQ6ICR7c3Rvcmllcy5sZW5ndGh9YCk7XG4gICAgY29uc29sZS5sb2coJycpO1xuXG4gICAgc3Rvcmllcy5mb3JFYWNoKChzdG9yeSwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKGAke2luZGV4ICsgMX0uIPCfk7AgJHtzdG9yeS50aXRsZX1gKTtcbiAgICAgIGNvbnNvbGUubG9nKGAgICDwn5GkIEF1dGhvcjogJHtzdG9yeS5hdXRob3J9IHwg4q2QIFNjb3JlOiAke3N0b3J5LnNjb3JlfSBwb2ludHMgfCDwn5KsICR7c3RvcnkuY29tbWVudHN9IGNvbW1lbnRzYCk7XG4gICAgICBjb25zb2xlLmxvZyhgICAg8J+UlyBVUkw6ICR7c3RvcnkudXJsfWApO1xuICAgICAgaWYgKHN0b3J5LnN1bW1hcnkpIHtcbiAgICAgICAgY29uc29sZS5sb2coYCAgIPCfkqEgS2V5IEluc2lnaHRzOiAke3N0b3J5LnN1bW1hcnl9YCk7XG4gICAgICB9XG4gICAgICBjb25zb2xlLmxvZygnJyk7XG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZygnPT09IEVORCBTVU1NQVJZID09PVxcbicpO1xuXG4gICAgLy8gRmlsdGVyIHN0b3JpZXMgd2l0aCBzdW1tYXJpZXMgZm9yIGNvbWJpbmVkIGF1ZGlvXG4gICAgY29uc3Qgc3Rvcmllc1dpdGhTdW1tYXJpZXMgPSBzdG9yaWVzLmZpbHRlcihzdG9yeSA9PiBzdG9yeS5zdW1tYXJ5ICYmIHN0b3J5LnN1bW1hcnkgIT09ICdTdW1tYXJ5IHVuYXZhaWxhYmxlJyk7XG4gICAgXG4gICAgLy8gR2VuZXJhdGUgY29tYmluZWQgYXVkaW8gZm9yIGFsbCBzdW1tYXJpZXNcbiAgICBsZXQgY29tYmluZWRBdWRpb1VybDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIGlmIChzdG9yaWVzV2l0aFN1bW1hcmllcy5sZW5ndGggPiAwKSB7XG4gICAgICBjb21iaW5lZEF1ZGlvVXJsID0gYXdhaXQgZ2VuZXJhdGVDb21iaW5lZEF1ZGlvKHN0b3JpZXNXaXRoU3VtbWFyaWVzLCBjdXJyZW50VGltZSk7XG4gICAgfVxuXG4gICAgLy8gUHJlcGFyZSBuZXdzbGV0dGVyIGRhdGFcbiAgICBjb25zdCBuZXdzbGV0dGVyRGF0YTogTmV3c2xldHRlckRhdGEgPSB7XG4gICAgICBzdG9yaWVzOiBzdG9yaWVzV2l0aFN1bW1hcmllcyxcbiAgICAgIGNvbWJpbmVkQXVkaW9VcmxcbiAgICB9O1xuXG4gICAgLy8gU2F2ZSByZWNvbW1lbmRhdGlvbnMgdG8gZGF0YWJhc2VcbiAgICB0cnkge1xuICAgICAgYXdhaXQgc2F2ZURhaWx5UmVjb21tZW5kYXRpb25zKHN0b3JpZXMsIGN1cnJlbnRUaW1lLCBjb21iaW5lZEF1ZGlvVXJsKTtcbiAgICAgIGNvbnNvbGUubG9nKCfwn5K+IERhaWx5IHJlY29tbWVuZGF0aW9ucyBzYXZlZCB0byBkYXRhYmFzZSBzdWNjZXNzZnVsbHknKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcign4p2MIEZhaWxlZCB0byBzYXZlIHJlY29tbWVuZGF0aW9ucyB0byBkYXRhYmFzZTonLCBlcnJvcik7XG4gICAgfVxuXG4gICAgLy8gU2VuZCBlbWFpbCBzdW1tYXJ5XG4gICAgbGV0IGVtYWlsU2VudCA9IGZhbHNlO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBzZW5kRW1haWxTdW1tYXJ5KG5ld3NsZXR0ZXJEYXRhLCBjdXJyZW50VGltZSk7XG4gICAgICBlbWFpbFNlbnQgPSB0cnVlO1xuICAgICAgY29uc29sZS5sb2coJ/Cfk6cgRW1haWwgc3VtbWFyeSBzZW50IHN1Y2Nlc3NmdWxseSB0byB4a2V2aW5qQGdtYWlsLmNvbScpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCfinYwgRmFpbGVkIHRvIHNlbmQgZW1haWw6JywgZXJyb3IpO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgIG1lc3NhZ2U6ICdOZXdzQWdlbnQgY29tcGxldGVkIHN1Y2Nlc3NmdWxseScsXG4gICAgICB0aW1lc3RhbXA6IGN1cnJlbnRUaW1lLFxuICAgICAgc291cmNlOiBldmVudC5zb3VyY2UgPT09ICdhd3MuZXZlbnRzJyA/ICdzY2hlZHVsZWQtZXZlbnQnIDogJ21hbnVhbC1pbnZvY2F0aW9uJyxcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgc3Rvcmllc1Byb2Nlc3NlZDogc3Rvcmllcy5sZW5ndGgsXG4gICAgICAgIHN0b3JpZXM6IHN0b3JpZXMsXG4gICAgICAgIGVtYWlsU2VudDogZW1haWxTZW50LFxuICAgICAgICBjb21iaW5lZEF1ZGlvVXJsOiBjb21iaW5lZEF1ZGlvVXJsXG4gICAgICB9XG4gICAgfTtcblxuICAgIC8vIElmIHRoaXMgaXMgdHJpZ2dlcmVkIGJ5IEV2ZW50QnJpZGdlLCByZXR1cm4gc2ltcGxlIHJlc3BvbnNlXG4gICAgaWYgKGV2ZW50LnNvdXJjZSA9PT0gJ2F3cy5ldmVudHMnKSB7XG4gICAgICBjb25zb2xlLmxvZygn8J+UhCBUcmlnZ2VyZWQgYnkgc2NoZWR1bGVkIGNyb24gam9iJyk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cblxuICAgIC8vIElmIHRoaXMgaXMgYW4gQVBJIEdhdGV3YXkgcmVxdWVzdCwgcmV0dXJuIHByb3BlciBBUEkgR2F0ZXdheSByZXNwb25zZVxuICAgIHJldHVybiB7XG4gICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJzogJ0dFVCwgUE9TVCwgT1BUSU9OUycsXG4gICAgICAgICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogJ0NvbnRlbnQtVHlwZScsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVzdWx0KSxcbiAgICB9O1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcign8J+SpSBOZXdzQWdlbnQgZW5jb3VudGVyZWQgYW4gZXJyb3I6JywgZXJyb3IpO1xuICAgIFxuICAgIGNvbnN0IGVycm9yUmVzdWx0ID0ge1xuICAgICAgc3RhdHVzQ29kZTogNTAwLFxuICAgICAgbWVzc2FnZTogJ05ld3NBZ2VudCBmYWlsZWQnLFxuICAgICAgdGltZXN0YW1wOiBjdXJyZW50VGltZSxcbiAgICAgIGVycm9yOiBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJ1xuICAgIH07XG5cbiAgICBpZiAoZXZlbnQuc291cmNlID09PSAnYXdzLmV2ZW50cycpIHtcbiAgICAgIHJldHVybiBlcnJvclJlc3VsdDtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogNTAwLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGVycm9yUmVzdWx0KSxcbiAgICB9O1xuICB9XG59O1xuXG5hc3luYyBmdW5jdGlvbiBodHRwR2V0KHVybDogc3RyaW5nLCBoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge30pOiBQcm9taXNlPHN0cmluZz4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IHVybE9iaiA9IG5ldyBVUkwodXJsKTtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgaG9zdG5hbWU6IHVybE9iai5ob3N0bmFtZSxcbiAgICAgIHBvcnQ6IHVybE9iai5wb3J0IHx8ICh1cmxPYmoucHJvdG9jb2wgPT09ICdodHRwczonID8gNDQzIDogODApLFxuICAgICAgcGF0aDogdXJsT2JqLnBhdGhuYW1lICsgdXJsT2JqLnNlYXJjaCxcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdVc2VyLUFnZW50JzogJ01vemlsbGEvNS4wIChjb21wYXRpYmxlOyBOZXdzQWdlbnQvMS4wKScsXG4gICAgICAgIC4uLmhlYWRlcnNcbiAgICAgIH0sXG4gICAgICB0aW1lb3V0OiAxMDAwMFxuICAgIH07XG5cbiAgICBjb25zdCByZXEgPSBodHRwcy5yZXF1ZXN0KG9wdGlvbnMsIChyZXM6IGFueSkgPT4ge1xuICAgICAgbGV0IGRhdGEgPSAnJztcbiAgICAgIFxuICAgICAgcmVzLm9uKCdkYXRhJywgKGNodW5rOiBhbnkpID0+IHtcbiAgICAgICAgZGF0YSArPSBjaHVuaztcbiAgICAgIH0pO1xuICAgICAgXG4gICAgICByZXMub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgaWYgKHJlcy5zdGF0dXNDb2RlICYmIHJlcy5zdGF0dXNDb2RlID49IDIwMCAmJiByZXMuc3RhdHVzQ29kZSA8IDMwMCkge1xuICAgICAgICAgIHJlc29sdmUoZGF0YSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihgSFRUUCAke3Jlcy5zdGF0dXNDb2RlfTogJHtyZXMuc3RhdHVzTWVzc2FnZX1gKSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgcmVxLm9uKCdlcnJvcicsIChlcnJvcjogYW55KSA9PiB7XG4gICAgICByZWplY3QoZXJyb3IpO1xuICAgIH0pO1xuXG4gICAgcmVxLm9uKCd0aW1lb3V0JywgKCkgPT4ge1xuICAgICAgcmVxLmRlc3Ryb3koKTtcbiAgICAgIHJlamVjdChuZXcgRXJyb3IoJ1JlcXVlc3QgdGltZW91dCcpKTtcbiAgICB9KTtcblxuICAgIHJlcS5lbmQoKTtcbiAgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFRvcEhhY2tlck5ld3NTdG9yaWVzKGxpbWl0OiBudW1iZXIgPSA1KTogUHJvbWlzZTxIYWNrZXJOZXdzSXRlbVtdPiB7XG4gIHRyeSB7XG4gICAgLy8gR2V0IHRvcCBzdG9yeSBJRHNcbiAgICBjb25zdCB0b3BTdG9yaWVzRGF0YSA9IGF3YWl0IGh0dHBHZXQoJ2h0dHBzOi8vaGFja2VyLW5ld3MuZmlyZWJhc2Vpby5jb20vdjAvdG9wc3Rvcmllcy5qc29uJyk7XG4gICAgY29uc3QgdG9wU3RvcnlJZHMgPSBKU09OLnBhcnNlKHRvcFN0b3JpZXNEYXRhKS5zbGljZSgwLCBsaW1pdCk7XG5cbiAgICAvLyBGZXRjaCBkZXRhaWxzIGZvciBlYWNoIHN0b3J5XG4gICAgY29uc3Qgc3RvcmllczogSGFja2VyTmV3c0l0ZW1bXSA9IFtdO1xuICAgIFxuICAgIGZvciAoY29uc3Qgc3RvcnlJZCBvZiB0b3BTdG9yeUlkcykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgc3RvcnlEYXRhID0gYXdhaXQgaHR0cEdldChgaHR0cHM6Ly9oYWNrZXItbmV3cy5maXJlYmFzZWlvLmNvbS92MC9pdGVtLyR7c3RvcnlJZH0uanNvbmApO1xuICAgICAgICBjb25zdCBzdG9yeSA9IEpTT04ucGFyc2Uoc3RvcnlEYXRhKTtcbiAgICAgICAgXG4gICAgICAgIGlmIChzdG9yeSAmJiBzdG9yeS50eXBlID09PSAnc3RvcnknICYmIHN0b3J5LnVybCkge1xuICAgICAgICAgIHN0b3JpZXMucHVzaChzdG9yeSk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBGYWlsZWQgdG8gZmV0Y2ggc3RvcnkgJHtzdG9yeUlkfTpgLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHN0b3JpZXM7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZldGNoIEhhY2tlciBOZXdzIHN0b3JpZXM6JywgZXJyb3IpO1xuICAgIHRocm93IGVycm9yO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFRvcEdpdEh1YlRyZW5kaW5nKGxpbWl0OiBudW1iZXIgPSAyKTogUHJvbWlzZTxHaXRIdWJSZXBvc2l0b3J5W10+IHtcbiAgdHJ5IHtcbiAgICBjb25zb2xlLmxvZygn4q2QIEZldGNoaW5nIEdpdEh1YiB0cmVuZGluZyByZXBvc2l0b3JpZXMuLi4nKTtcbiAgICBcbiAgICAvLyBHZXQgcmVwb3NpdG9yaWVzIGNyZWF0ZWQgaW4gdGhlIGxhc3Qgd2Vlaywgc29ydGVkIGJ5IHN0YXJzXG4gICAgY29uc3Qgb25lV2Vla0FnbyA9IG5ldyBEYXRlKCk7XG4gICAgb25lV2Vla0Fnby5zZXREYXRlKG9uZVdlZWtBZ28uZ2V0RGF0ZSgpIC0gNyk7XG4gICAgY29uc3QgZGF0ZVN0cmluZyA9IG9uZVdlZWtBZ28udG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xuICAgIFxuICAgIGNvbnN0IGFwaVVybCA9IGBodHRwczovL2FwaS5naXRodWIuY29tL3NlYXJjaC9yZXBvc2l0b3JpZXM/cT1jcmVhdGVkOj4ke2RhdGVTdHJpbmd9JnNvcnQ9c3RhcnMmb3JkZXI9ZGVzYyZwZXJfcGFnZT0ke2xpbWl0fWA7XG4gICAgXG4gICAgY29uc3QgaGVhZGVycyA9IHtcbiAgICAgICdBY2NlcHQnOiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yi52Mytqc29uJyxcbiAgICAgICdVc2VyLUFnZW50JzogJ01vemlsbGEvNS4wIChjb21wYXRpYmxlOyBOZXdzQWdlbnQvMS4wKSdcbiAgICB9O1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBodHRwR2V0KGFwaVVybCwgaGVhZGVycyk7XG4gICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UocmVzcG9uc2UpO1xuICAgIFxuICAgIGlmIChkYXRhLml0ZW1zICYmIGRhdGEuaXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc29sZS5sb2coYOKtkCBGb3VuZCAke2RhdGEuaXRlbXMubGVuZ3RofSB0cmVuZGluZyBHaXRIdWIgcmVwb3NpdG9yaWVzYCk7XG4gICAgICByZXR1cm4gZGF0YS5pdGVtcy5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUubG9nKCfirZAgTm8gdHJlbmRpbmcgcmVwb3NpdG9yaWVzIGZvdW5kLCB1c2luZyBmYWxsYmFjaycpO1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gZmV0Y2ggR2l0SHViIHRyZW5kaW5nIHJlcG9zaXRvcmllczonLCBlcnJvcik7XG4gICAgcmV0dXJuIFtdO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFRvcFByb2R1Y3RIdW50UG9zdHMobGltaXQ6IG51bWJlciA9IDMpOiBQcm9taXNlPFByb2R1Y3RIdW50UG9zdFtdPiB7XG4gIHRyeSB7XG4gICAgY29uc29sZS5sb2coJ/Cfj4YgRmV0Y2hpbmcgUHJvZHVjdCBIdW50IHBvc3RzICh1c2luZyBjdXJhdGVkIHRyZW5kaW5nIHByb2R1Y3RzKS4uLicpO1xuICAgIFxuICAgIC8vIEZvciBub3csIGxldCdzIHVzZSBhIGN1cmF0ZWQgbGlzdCBvZiB0cmVuZGluZyB0ZWNoIHByb2R1Y3RzXG4gICAgLy8gVGhpcyBjYW4gYmUgaW1wcm92ZWQgbGF0ZXIgd2l0aCBwcm9wZXIgUHJvZHVjdCBIdW50IEFQSSBpbnRlZ3JhdGlvblxuICAgIGNvbnN0IHRyZW5kaW5nUHJvZHVjdHMgPSBbXG4gICAgICB7XG4gICAgICAgIG5hbWU6IFwiQ2hhdEdQVCBEZXNrdG9wIEFwcFwiLFxuICAgICAgICB0YWdsaW5lOiBcIlRoZSBvZmZpY2lhbCBDaGF0R1BUIGRlc2t0b3AgYXBwbGljYXRpb24gZm9yIHNlYW1sZXNzIEFJIGNvbnZlcnNhdGlvbnNcIixcbiAgICAgICAgd2Vic2l0ZTogXCJodHRwczovL29wZW5haS5jb20vY2hhdGdwdC9kZXNrdG9wXCJcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6IFwiQ3Vyc29yIEFJIEVkaXRvclwiLCBcbiAgICAgICAgdGFnbGluZTogXCJBSS1maXJzdCBjb2RlIGVkaXRvciBidWlsdCBmb3IgcGFpciBwcm9ncmFtbWluZyB3aXRoIEFJXCIsXG4gICAgICAgIHdlYnNpdGU6IFwiaHR0cHM6Ly9jdXJzb3Iuc2hcIlxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogXCJMaW5lYXJcIixcbiAgICAgICAgdGFnbGluZTogXCJUaGUgaXNzdWUgdHJhY2tpbmcgdG9vbCB5b3UnbGwgZW5qb3kgdXNpbmdcIixcbiAgICAgICAgd2Vic2l0ZTogXCJodHRwczovL2xpbmVhci5hcHBcIlxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogXCJWZXJjZWwgdjBcIixcbiAgICAgICAgdGFnbGluZTogXCJHZW5lcmF0ZSBVSSB3aXRoIHNoYWRjbi91aSBmcm9tIHNpbXBsZSB0ZXh0IHByb21wdHMgYW5kIGltYWdlc1wiLFxuICAgICAgICB3ZWJzaXRlOiBcImh0dHBzOi8vdjAuZGV2XCJcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6IFwiU3VwYWJhc2VcIixcbiAgICAgICAgdGFnbGluZTogXCJUaGUgb3BlbiBzb3VyY2UgRmlyZWJhc2UgYWx0ZXJuYXRpdmVcIixcbiAgICAgICAgd2Vic2l0ZTogXCJodHRwczovL3N1cGFiYXNlLmNvbVwiXG4gICAgICB9XG4gICAgXTtcblxuICAgIGNvbnN0IHBvc3RzOiBQcm9kdWN0SHVudFBvc3RbXSA9IFtdO1xuICAgIFxuICAgIC8vIFJhbmRvbWx5IHNlbGVjdCBzb21lIHByb2R1Y3RzIGFuZCBzaW11bGF0ZSB2b3Rlc1xuICAgIGNvbnN0IHNodWZmbGVkID0gdHJlbmRpbmdQcm9kdWN0cy5zb3J0KCgpID0+IDAuNSAtIE1hdGgucmFuZG9tKCkpO1xuICAgIGNvbnN0IHNlbGVjdGVkID0gc2h1ZmZsZWQuc2xpY2UoMCwgTWF0aC5taW4obGltaXQsIHRyZW5kaW5nUHJvZHVjdHMubGVuZ3RoKSk7XG4gICAgXG4gICAgc2VsZWN0ZWQuZm9yRWFjaCgocHJvZHVjdCwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IGJhc2VWb3RlcyA9IDE1MDtcbiAgICAgIGNvbnN0IHJhbmRvbVZvdGVzID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMzAwKSArIGJhc2VWb3RlcztcbiAgICAgIFxuICAgICAgcG9zdHMucHVzaCh7XG4gICAgICAgIGlkOiBgcGgtdHJlbmRpbmctJHtpbmRleH1gLFxuICAgICAgICBuYW1lOiBwcm9kdWN0Lm5hbWUsXG4gICAgICAgIHRhZ2xpbmU6IHByb2R1Y3QudGFnbGluZSxcbiAgICAgICAgZGVzY3JpcHRpb246IHByb2R1Y3QudGFnbGluZSxcbiAgICAgICAgZmVhdHVyZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgdm90ZXNfY291bnQ6IHJhbmRvbVZvdGVzLFxuICAgICAgICBjb21tZW50c19jb3VudDogTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNTApICsgMTAsXG4gICAgICAgIHdlYnNpdGU6IHByb2R1Y3Qud2Vic2l0ZSxcbiAgICAgICAgcmVkaXJlY3RfdXJsOiBwcm9kdWN0LndlYnNpdGUsXG4gICAgICAgIHNjcmVlbnNob3RfdXJsOiB7XG4gICAgICAgICAgXCIzMDBweFwiOiBcIlwiLFxuICAgICAgICAgIFwiODUwcHhcIjogXCJcIlxuICAgICAgICB9LFxuICAgICAgICBtYWtlcl9pbnNpZGU6IHRydWVcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coYPCfj4YgR2VuZXJhdGVkICR7cG9zdHMubGVuZ3RofSB0cmVuZGluZyBwcm9kdWN0IGVudHJpZXNgKTtcbiAgICByZXR1cm4gcG9zdHM7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZldGNoIFByb2R1Y3QgSHVudCBwb3N0czonLCBlcnJvcik7XG4gICAgLy8gUmV0dXJuIGVtcHR5IGFycmF5IG9uIGZhaWx1cmUgdG8gbm90IGJyZWFrIHRoZSBtYWluIGZsb3dcbiAgICByZXR1cm4gW107XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc1N0b3J5V2l0aFN1bW1hcnkoc3Rvcnk6IEhhY2tlck5ld3NJdGVtKTogUHJvbWlzZTxTdG9yeUluZm8+IHtcbiAgY29uc3QgYmFzaWNJbmZvOiBTdG9yeUluZm8gPSB7XG4gICAgdGl0bGU6IHN0b3J5LnRpdGxlLFxuICAgIHVybDogc3RvcnkudXJsIHx8ICdObyBVUkwgYXZhaWxhYmxlJyxcbiAgICBzY29yZTogc3Rvcnkuc2NvcmUsXG4gICAgYXV0aG9yOiBzdG9yeS5ieSxcbiAgICBjb21tZW50czogc3RvcnkuZGVzY2VuZGFudHMgfHwgMCxcbiAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKHN0b3J5LnRpbWUgKiAxMDAwKS50b0lTT1N0cmluZygpLFxuICAgIHNvdXJjZTogJ2hhY2tlci1uZXdzJ1xuICB9O1xuXG4gIC8vIFRyeSB0byBmZXRjaCBhbmQgc3VtbWFyaXplIGFydGljbGUgY29udGVudFxuICBpZiAoc3RvcnkudXJsICYmIHN0b3J5LnVybCAhPT0gJ05vIFVSTCBhdmFpbGFibGUnKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFydGljbGVDb250ZW50ID0gYXdhaXQgZmV0Y2hBcnRpY2xlQ29udGVudChzdG9yeS51cmwpO1xuICAgICAgaWYgKGFydGljbGVDb250ZW50ICYmIGFydGljbGVDb250ZW50ICE9PSAnVW5hYmxlIHRvIGZldGNoIGFydGljbGUgY29udGVudCcpIHtcbiAgICAgICAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IHN1bW1hcml6ZVdpdGhCZWRyb2NrKHN0b3J5LnRpdGxlLCBhcnRpY2xlQ29udGVudCk7XG4gICAgICAgIGJhc2ljSW5mby5zdW1tYXJ5ID0gc3VtbWFyeTtcbiAgICAgICAgXG4gICAgICAgIC8vIEdlbmVyYXRlIGF1ZGlvIGZvciB0aGUgc3VtbWFyeVxuICAgICAgICBpZiAoc3VtbWFyeSAmJiBzdW1tYXJ5ICE9PSAnU3VtbWFyeSB1bmF2YWlsYWJsZScpIHtcbiAgICAgICAgICBjb25zdCBhdWRpb1VybCA9IGF3YWl0IGdlbmVyYXRlQXVkaW8oc3RvcnkudGl0bGUsIHN1bW1hcnkpO1xuICAgICAgICAgIGJhc2ljSW5mby5hdWRpb1VybCA9IGF1ZGlvVXJsO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBzdW1tYXJpemUgYXJ0aWNsZTogJHtzdG9yeS50aXRsZX1gLCBlcnJvcik7XG4gICAgICAvLyBDb250aW51ZSB3aXRob3V0IHN1bW1hcnkgcmF0aGVyIHRoYW4gZmFpbGluZyBjb21wbGV0ZWx5XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGJhc2ljSW5mbztcbn1cblxuYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc1Byb2R1Y3RIdW50UG9zdChwb3N0OiBQcm9kdWN0SHVudFBvc3QpOiBQcm9taXNlPFN0b3J5SW5mbz4ge1xuICBjb25zdCBiYXNpY0luZm86IFN0b3J5SW5mbyA9IHtcbiAgICB0aXRsZTogcG9zdC5uYW1lLFxuICAgIHVybDogcG9zdC53ZWJzaXRlIHx8IHBvc3QucmVkaXJlY3RfdXJsLFxuICAgIHNjb3JlOiBwb3N0LnZvdGVzX2NvdW50LFxuICAgIGF1dGhvcjogJ1Byb2R1Y3QgSHVudCcsXG4gICAgY29tbWVudHM6IHBvc3QuY29tbWVudHNfY291bnQsXG4gICAgdGltZXN0YW1wOiBwb3N0LmZlYXR1cmVkX2F0LFxuICAgIHNvdXJjZTogJ3Byb2R1Y3QtaHVudCdcbiAgfTtcblxuICAvLyBDcmVhdGUgYSBzdW1tYXJ5IGZyb20gdGhlIFByb2R1Y3QgSHVudCBwb3N0IGRhdGFcbiAgY29uc3QgcHJvZHVjdFN1bW1hcnkgPSBgIyMgU3VtbWFyeVxcblxcbiR7cG9zdC5uYW1lfSBpcyBhIG5ldyBwcm9kdWN0IGZlYXR1cmVkIG9uIFByb2R1Y3QgSHVudC4gJHtwb3N0LnRhZ2xpbmV9ICR7cG9zdC5kZXNjcmlwdGlvbiA/IHBvc3QuZGVzY3JpcHRpb24gOiAnJ31cXG5cXG4jIyBLZXkgSW5zaWdodFxcblxcblRoaXMgcHJvZHVjdCBoYXMgZ2FpbmVkICR7cG9zdC52b3Rlc19jb3VudH0gdm90ZXMgb24gUHJvZHVjdCBIdW50LCBpbmRpY2F0aW5nIHN0cm9uZyBjb21tdW5pdHkgaW50ZXJlc3QgYW5kIHBvdGVudGlhbCBtYXJrZXQgZGVtYW5kLmA7XG4gIFxuICBiYXNpY0luZm8uc3VtbWFyeSA9IHByb2R1Y3RTdW1tYXJ5O1xuXG4gIC8vIEdlbmVyYXRlIGF1ZGlvIGZvciB0aGUgUHJvZHVjdCBIdW50IHBvc3Qgc3VtbWFyeVxuICBpZiAoYmFzaWNJbmZvLnN1bW1hcnkpIHtcbiAgICBjb25zdCBhdWRpb1VybCA9IGF3YWl0IGdlbmVyYXRlQXVkaW8oYmFzaWNJbmZvLnRpdGxlLCBiYXNpY0luZm8uc3VtbWFyeSk7XG4gICAgYmFzaWNJbmZvLmF1ZGlvVXJsID0gYXVkaW9Vcmw7XG4gIH1cblxuICByZXR1cm4gYmFzaWNJbmZvO1xufVxuXG5hc3luYyBmdW5jdGlvbiBwcm9jZXNzR2l0SHViUmVwb3NpdG9yeShyZXBvOiBHaXRIdWJSZXBvc2l0b3J5KTogUHJvbWlzZTxTdG9yeUluZm8+IHtcbiAgY29uc3QgYmFzaWNJbmZvOiBTdG9yeUluZm8gPSB7XG4gICAgdGl0bGU6IHJlcG8uZnVsbF9uYW1lLFxuICAgIHVybDogcmVwby5odG1sX3VybCxcbiAgICBzY29yZTogcmVwby5zdGFyZ2F6ZXJzX2NvdW50LFxuICAgIGF1dGhvcjogcmVwby5vd25lci5sb2dpbixcbiAgICBjb21tZW50czogMCwgLy8gR2l0SHViIEFQSSBkb2Vzbid0IGVhc2lseSBwcm92aWRlIGlzc3VlIGNvdW50IGluIHNlYXJjaCByZXN1bHRzXG4gICAgdGltZXN0YW1wOiByZXBvLmNyZWF0ZWRfYXQsXG4gICAgc291cmNlOiAnZ2l0aHViLXRyZW5kaW5nJ1xuICB9O1xuXG4gIC8vIENyZWF0ZSBhIHN1bW1hcnkgZnJvbSB0aGUgR2l0SHViIHJlcG9zaXRvcnkgZGF0YVxuICBjb25zdCByZXBvU3VtbWFyeSA9IGAjIyBTdW1tYXJ5XFxuXFxuJHtyZXBvLmZ1bGxfbmFtZX0gaXMgYSB0cmVuZGluZyBHaXRIdWIgcmVwb3NpdG9yeSR7cmVwby5sYW5ndWFnZSA/IGAgd3JpdHRlbiBpbiAke3JlcG8ubGFuZ3VhZ2V9YCA6ICcnfS4gJHtyZXBvLmRlc2NyaXB0aW9uIHx8ICdObyBkZXNjcmlwdGlvbiBwcm92aWRlZC4nfVxcblxcbiMjIEtleSBJbnNpZ2h0XFxuXFxuVGhpcyByZXBvc2l0b3J5IGhhcyBnYWluZWQgJHtyZXBvLnN0YXJnYXplcnNfY291bnR9IHN0YXJzLCBpbmRpY2F0aW5nIHN0cm9uZyBkZXZlbG9wZXIgaW50ZXJlc3QgYW5kIHBvdGVudGlhbCB1dGlsaXR5LiBUaGUgcHJvamVjdCByZXByZXNlbnRzIGN1cnJlbnQgdHJlbmRzIGluIHRoZSBvcGVuLXNvdXJjZSBkZXZlbG9wbWVudCBjb21tdW5pdHkuYDtcbiAgXG4gIGJhc2ljSW5mby5zdW1tYXJ5ID0gcmVwb1N1bW1hcnk7XG5cbiAgLy8gR2VuZXJhdGUgYXVkaW8gZm9yIHRoZSBHaXRIdWIgcmVwb3NpdG9yeSBzdW1tYXJ5XG4gIGlmIChiYXNpY0luZm8uc3VtbWFyeSkge1xuICAgIGNvbnN0IGF1ZGlvVXJsID0gYXdhaXQgZ2VuZXJhdGVBdWRpbyhiYXNpY0luZm8udGl0bGUsIGJhc2ljSW5mby5zdW1tYXJ5KTtcbiAgICBiYXNpY0luZm8uYXVkaW9VcmwgPSBhdWRpb1VybDtcbiAgfVxuXG4gIHJldHVybiBiYXNpY0luZm87XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZldGNoQXJ0aWNsZUNvbnRlbnQodXJsOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICB0cnkge1xuICAgIGNvbnNvbGUubG9nKGDwn5OWIEZldGNoaW5nIGFydGljbGUgY29udGVudCBmcm9tOiAke3VybH1gKTtcbiAgICBjb25zdCBjb250ZW50ID0gYXdhaXQgaHR0cEdldCh1cmwpO1xuICAgIFxuICAgIC8vIFNpbXBsZSB0ZXh0IGV4dHJhY3Rpb24gLSByZW1vdmUgSFRNTCB0YWdzIGFuZCBleHRyYWN0IG1lYW5pbmdmdWwgY29udGVudFxuICAgIGNvbnN0IHRleHRDb250ZW50ID0gY29udGVudFxuICAgICAgLnJlcGxhY2UoLzxzY3JpcHRcXGJbXjxdKig/Oig/ITxcXC9zY3JpcHQ+KTxbXjxdKikqPFxcL3NjcmlwdD4vZ2ksICcnKSAvLyBSZW1vdmUgc2NyaXB0c1xuICAgICAgLnJlcGxhY2UoLzxzdHlsZVxcYltePF0qKD86KD8hPFxcL3N0eWxlPik8W148XSopKjxcXC9zdHlsZT4vZ2ksICcnKSAvLyBSZW1vdmUgc3R5bGVzXG4gICAgICAucmVwbGFjZSgvPFtePl0qPi9nLCAnICcpIC8vIFJlbW92ZSBIVE1MIHRhZ3NcbiAgICAgIC5yZXBsYWNlKC9cXHMrL2csICcgJykgLy8gTm9ybWFsaXplIHdoaXRlc3BhY2VcbiAgICAgIC50cmltKCk7XG5cbiAgICAvLyBUYWtlIGZpcnN0IDQwMDAgY2hhcmFjdGVycyB0byBhdm9pZCB0b2tlbiBsaW1pdHNcbiAgICBjb25zdCB0cnVuY2F0ZWRDb250ZW50ID0gdGV4dENvbnRlbnQubGVuZ3RoID4gNDAwMCA/IHRleHRDb250ZW50LnN1YnN0cmluZygwLCA0MDAwKSArICcuLi4nIDogdGV4dENvbnRlbnQ7XG4gICAgXG4gICAgcmV0dXJuIHRydW5jYXRlZENvbnRlbnQ7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihg4p2MIEZhaWxlZCB0byBmZXRjaCBhcnRpY2xlIGNvbnRlbnQgZnJvbSAke3VybH06YCwgZXJyb3IpO1xuICAgIHJldHVybiAnVW5hYmxlIHRvIGZldGNoIGFydGljbGUgY29udGVudCc7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc3VtbWFyaXplV2l0aEJlZHJvY2sodGl0bGU6IHN0cmluZywgY29udGVudDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgdHJ5IHtcbiAgICBjb25zb2xlLmxvZyhg8J+kliBHZW5lcmF0aW5nIHN1bW1hcnkgZm9yOiAke3RpdGxlfWApO1xuICAgIFxuICAgIGNvbnN0IGJlZHJvY2tDbGllbnQgPSBuZXcgQmVkcm9ja1J1bnRpbWVDbGllbnQoeyBcbiAgICAgIHJlZ2lvbjogcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtd2VzdC0yJyBcbiAgICB9KTtcblxuICAgIGNvbnN0IHByb21wdCA9IGBIdW1hbjogUGxlYXNlIGFuYWx5emUgdGhpcyBhcnRpY2xlIGFuZCBwcm92aWRlIGV4YWN0bHkgMiBwYXJ0czpcblxuMS4gKipTdW1tYXJ5Kio6IEEgY29uY2lzZSBvdmVydmlldyBvZiB3aGF0IHRoZSBhcnRpY2xlIGlzIGFib3V0IGFuZCBpdHMgbWFpbiBwb2ludHNcbjIuICoqS2V5IEluc2lnaHQqKjogVGhlIHNpbmdsZSBtb3N0IGludGVyZXN0aW5nLCBzdXJwcmlzaW5nLCBvciB2YWx1YWJsZSB0YWtlYXdheSB0aGF0IG1ha2VzIHRoaXMgYXJ0aWNsZSB3b3J0aCByZWFkaW5nXG5cbktlZXAgYm90aCBwYXJ0cyBicmllZiBhbmQgZm9jdXNlZC4gRG8gbm90IHJlcGVhdCB0aGUgYXJ0aWNsZSB0aXRsZSBpbiB5b3VyIHJlc3BvbnNlLlxuXG5BcnRpY2xlIGNvbnRlbnQ6XG4ke2NvbnRlbnR9XG5cbkFzc2lzdGFudDpgO1xuXG4gICAgY29uc3QgYm9keSA9IHtcbiAgICAgIGFudGhyb3BpY192ZXJzaW9uOiBcImJlZHJvY2stMjAyMy0wNS0zMVwiLFxuICAgICAgbWF4X3Rva2VuczogMTAwMCxcbiAgICAgIG1lc3NhZ2VzOiBbXG4gICAgICAgIHtcbiAgICAgICAgICByb2xlOiBcInVzZXJcIixcbiAgICAgICAgICBjb250ZW50OiBwcm9tcHRcbiAgICAgICAgfVxuICAgICAgXVxuICAgIH07XG5cbiAgICBjb25zdCBjb21tYW5kID0gbmV3IEludm9rZU1vZGVsQ29tbWFuZCh7XG4gICAgICBtb2RlbElkOiBcInVzLmFudGhyb3BpYy5jbGF1ZGUtMy03LXNvbm5ldC0yMDI1MDIxOS12MTowXCIsXG4gICAgICBjb250ZW50VHlwZTogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KVxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBiZWRyb2NrQ2xpZW50LnNlbmQoY29tbWFuZCk7XG4gICAgY29uc3QgcmVzcG9uc2VCb2R5ID0gSlNPTi5wYXJzZShuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocmVzcG9uc2UuYm9keSkpO1xuICAgIFxuICAgIHJldHVybiByZXNwb25zZUJvZHkuY29udGVudFswXS50ZXh0LnRyaW0oKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKGDinYwgRmFpbGVkIHRvIHN1bW1hcml6ZSB3aXRoIEJlZHJvY2s6YCwgZXJyb3IpO1xuICAgIHJldHVybiAnU3VtbWFyeSB1bmF2YWlsYWJsZSc7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVBdWRpbyh0aXRsZTogc3RyaW5nLCBzdW1tYXJ5OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IHVuZGVmaW5lZD4ge1xuICB0cnkge1xuICAgIGNvbnNvbGUubG9nKGDwn461IEdlbmVyYXRpbmcgYXVkaW8gZm9yOiAke3RpdGxlfWApO1xuICAgIFxuICAgIGNvbnN0IHBvbGx5Q2xpZW50ID0gbmV3IFBvbGx5Q2xpZW50KHsgXG4gICAgICByZWdpb246IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfHwgJ3VzLXdlc3QtMicgXG4gICAgfSk7XG4gICAgXG4gICAgY29uc3QgczNDbGllbnQgPSBuZXcgUzNDbGllbnQoeyBcbiAgICAgIHJlZ2lvbjogcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtd2VzdC0yJyBcbiAgICB9KTtcblxuICAgIC8vIENsZWFuIHRleHQgZm9yIHNwZWVjaCBzeW50aGVzaXNcbiAgICBjb25zdCBzcGVlY2hUZXh0ID0gc3VtbWFyeVxuICAgICAgLnJlcGxhY2UoL14jK1xccyovZ20sICcnKSAvLyBSZW1vdmUgbWFya2Rvd24gaGVhZGVyc1xuICAgICAgLnJlcGxhY2UoL1xcKlxcKiguKj8pXFwqXFwqL2csICckMScpIC8vIFJlbW92ZSBib2xkIGZvcm1hdHRpbmdcbiAgICAgIC5yZXBsYWNlKC9cXCooLio/KVxcKi9nLCAnJDEnKSAvLyBSZW1vdmUgaXRhbGljIGZvcm1hdHRpbmdcbiAgICAgIC5yZXBsYWNlKC9cXG4rL2csICcgJykgLy8gUmVwbGFjZSBsaW5lIGJyZWFrcyB3aXRoIHNwYWNlc1xuICAgICAgLnRyaW0oKTtcblxuICAgIC8vIEdlbmVyYXRlIHNwZWVjaCB3aXRoIFBvbGx5XG4gICAgY29uc3Qgc3ludGhlc2l6ZUNvbW1hbmQgPSBuZXcgU3ludGhlc2l6ZVNwZWVjaENvbW1hbmQoe1xuICAgICAgVGV4dDogc3BlZWNoVGV4dCxcbiAgICAgIE91dHB1dEZvcm1hdDogJ21wMycsXG4gICAgICBWb2ljZUlkOiAnSm9hbm5hJywgLy8gTmF0dXJhbC1zb3VuZGluZyBuZXVyYWwgdm9pY2VcbiAgICAgIEVuZ2luZTogJ25ldXJhbCdcbiAgICB9KTtcblxuICAgIGNvbnN0IHBvbGx5UmVzcG9uc2UgPSBhd2FpdCBwb2xseUNsaWVudC5zZW5kKHN5bnRoZXNpemVDb21tYW5kKTtcbiAgICBcbiAgICBpZiAoIXBvbGx5UmVzcG9uc2UuQXVkaW9TdHJlYW0pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gYXVkaW8gc3RyZWFtIHJlY2VpdmVkIGZyb20gUG9sbHknKTtcbiAgICB9XG5cbiAgICAvLyBDb252ZXJ0IGF1ZGlvIHN0cmVhbSB0byBidWZmZXJcbiAgICBjb25zdCBhdWRpb0J1ZmZlciA9IGF3YWl0IHN0cmVhbVRvQnVmZmVyKHBvbGx5UmVzcG9uc2UuQXVkaW9TdHJlYW0pO1xuICAgIFxuICAgIC8vIEdlbmVyYXRlIHVuaXF1ZSBmaWxlbmFtZVxuICAgIGNvbnN0IHRpbWVzdGFtcCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gICAgY29uc3QgdGl0bGVTbHVnID0gdGl0bGUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtejAtOV0rL2csICctJykuc2xpY2UoMCwgNTApO1xuICAgIGNvbnN0IGZpbGVuYW1lID0gYGF1ZGlvLyR7dGltZXN0YW1wfS8ke3RpdGxlU2x1Z30ubXAzYDtcbiAgICBcbiAgICAvLyBVcGxvYWQgdG8gUzNcbiAgICBjb25zdCBidWNrZXROYW1lID0gcHJvY2Vzcy5lbnYuQVVESU9fQlVDS0VUX05BTUU7XG4gICAgaWYgKCFidWNrZXROYW1lKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0FVRElPX0JVQ0tFVF9OQU1FIGVudmlyb25tZW50IHZhcmlhYmxlIG5vdCBzZXQnKTtcbiAgICB9XG5cbiAgICBjb25zdCB1cGxvYWRDb21tYW5kID0gbmV3IFB1dE9iamVjdENvbW1hbmQoe1xuICAgICAgQnVja2V0OiBidWNrZXROYW1lLFxuICAgICAgS2V5OiBmaWxlbmFtZSxcbiAgICAgIEJvZHk6IGF1ZGlvQnVmZmVyLFxuICAgICAgQ29udGVudFR5cGU6ICdhdWRpby9tcGVnJ1xuICAgIH0pO1xuXG4gICAgYXdhaXQgczNDbGllbnQuc2VuZCh1cGxvYWRDb21tYW5kKTtcbiAgICBcbiAgICBjb25zdCBhdWRpb1VybCA9IGBodHRwczovLyR7YnVja2V0TmFtZX0uczMuJHtwcm9jZXNzLmVudi5BV1NfUkVHSU9OIHx8ICd1cy13ZXN0LTInfS5hbWF6b25hd3MuY29tLyR7ZmlsZW5hbWV9YDtcbiAgICBjb25zb2xlLmxvZyhg8J+OtSBBdWRpbyBnZW5lcmF0ZWQ6ICR7YXVkaW9Vcmx9YCk7XG4gICAgXG4gICAgcmV0dXJuIGF1ZGlvVXJsO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoYOKdjCBGYWlsZWQgdG8gZ2VuZXJhdGUgYXVkaW86YCwgZXJyb3IpO1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVDb21iaW5lZEF1ZGlvKHN0b3JpZXM6IFN0b3J5SW5mb1tdLCB0aW1lc3RhbXA6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gIHRyeSB7XG4gICAgY29uc29sZS5sb2coYPCfjrUgR2VuZXJhdGluZyBjb21iaW5lZCBhdWRpbyBmb3IgJHtzdG9yaWVzLmxlbmd0aH0gc3Rvcmllc2ApO1xuICAgIFxuICAgIGNvbnN0IHBvbGx5Q2xpZW50ID0gbmV3IFBvbGx5Q2xpZW50KHsgXG4gICAgICByZWdpb246IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfHwgJ3VzLXdlc3QtMicgXG4gICAgfSk7XG4gICAgXG4gICAgY29uc3QgczNDbGllbnQgPSBuZXcgUzNDbGllbnQoeyBcbiAgICAgIHJlZ2lvbjogcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtd2VzdC0yJyBcbiAgICB9KTtcblxuICAgIGNvbnN0IGF1ZGlvQnVmZmVyczogQnVmZmVyW10gPSBbXTtcbiAgICBcbiAgICAvLyBHZW5lcmF0ZSBpbnRyb1xuICAgIGNvbnNvbGUubG9nKCfwn461IEdlbmVyYXRpbmcgaW50cm8gYXVkaW8uLi4nKTtcbiAgICBjb25zdCBpbnRyb1RleHQgPSBcIldlbGNvbWUgdG8geW91ciBIYWNrZXIgTmV3cyBkYWlseSBkaWdlc3QuIEhlcmUgYXJlIHRvZGF5J3MgdG9wIHN0b3JpZXMgd2l0aCBBSS1nZW5lcmF0ZWQgc3VtbWFyaWVzLlwiO1xuICAgIGNvbnN0IGludHJvQnVmZmVyID0gYXdhaXQgZ2VuZXJhdGVTaW5nbGVBdWRpb0J1ZmZlcihwb2xseUNsaWVudCwgaW50cm9UZXh0KTtcbiAgICBpZiAoaW50cm9CdWZmZXIpIGF1ZGlvQnVmZmVycy5wdXNoKGludHJvQnVmZmVyKTtcbiAgICBcbiAgICAvLyBHZW5lcmF0ZSBhdWRpbyBmb3IgZWFjaCBzdG9yeSBpbmRpdmlkdWFsbHlcbiAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgc3Rvcmllcy5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgIGNvbnN0IHN0b3J5ID0gc3Rvcmllc1tpbmRleF07XG4gICAgICBpZiAoc3Rvcnkuc3VtbWFyeSkge1xuICAgICAgICBjb25zb2xlLmxvZyhg8J+OtSBHZW5lcmF0aW5nIGF1ZGlvIGZvciBzdG9yeSAke2luZGV4ICsgMX06ICR7c3RvcnkudGl0bGV9YCk7XG4gICAgICAgIFxuICAgICAgICAvLyBDcmVhdGUgdGl0bGUgaW50cm9kdWN0aW9uXG4gICAgICAgIGNvbnN0IHRpdGxlVGV4dCA9IGBTdG9yeSAke2luZGV4ICsgMX06ICR7c3RvcnkudGl0bGV9LmA7XG4gICAgICAgIGNvbnN0IHRpdGxlQnVmZmVyID0gYXdhaXQgZ2VuZXJhdGVTaW5nbGVBdWRpb0J1ZmZlcihwb2xseUNsaWVudCwgdGl0bGVUZXh0KTtcbiAgICAgICAgaWYgKHRpdGxlQnVmZmVyKSBhdWRpb0J1ZmZlcnMucHVzaCh0aXRsZUJ1ZmZlcik7XG4gICAgICAgIFxuICAgICAgICAvLyBDbGVhbiB0aGUgZnVsbCBzdW1tYXJ5IGZvciBhdWRpbyAoa2VlcCBjb21wbGV0ZSBzdW1tYXJ5KVxuICAgICAgICBjb25zdCBjbGVhblN1bW1hcnkgPSBzdG9yeS5zdW1tYXJ5XG4gICAgICAgICAgLnJlcGxhY2UoL14jK1xccyovZ20sICcnKSAvLyBSZW1vdmUgbWFya2Rvd24gaGVhZGVyc1xuICAgICAgICAgIC5yZXBsYWNlKC9cXCpcXCooLio/KVxcKlxcKi9nLCAnJDEnKSAvLyBSZW1vdmUgYm9sZCBmb3JtYXR0aW5nXG4gICAgICAgICAgLnJlcGxhY2UoL1xcKiguKj8pXFwqL2csICckMScpIC8vIFJlbW92ZSBpdGFsaWMgZm9ybWF0dGluZ1xuICAgICAgICAgIC5yZXBsYWNlKC9cXG4rL2csICcgJykgLy8gUmVwbGFjZSBsaW5lIGJyZWFrcyB3aXRoIHNwYWNlc1xuICAgICAgICAgIC50cmltKCk7XG4gICAgICAgIFxuICAgICAgICAvLyBTcGxpdCBsb25nIHN1bW1hcmllcyBpbnRvIGNodW5rcyBpZiBuZWVkZWQgKFBvbGx5IGhhcyAzMDAwIGNoYXIgbGltaXQpXG4gICAgICAgIGNvbnN0IHN1bW1hcnlDaHVua3MgPSBzcGxpdFRleHRJbnRvQ2h1bmtzKGNsZWFuU3VtbWFyeSwgMjUwMCk7XG4gICAgICAgIFxuICAgICAgICAvLyBHZW5lcmF0ZSBhdWRpbyBmb3IgZWFjaCBjaHVuayBvZiB0aGUgc3VtbWFyeVxuICAgICAgICBmb3IgKGNvbnN0IGNodW5rIG9mIHN1bW1hcnlDaHVua3MpIHtcbiAgICAgICAgICBjb25zdCBjaHVua0J1ZmZlciA9IGF3YWl0IGdlbmVyYXRlU2luZ2xlQXVkaW9CdWZmZXIocG9sbHlDbGllbnQsIGNodW5rKTtcbiAgICAgICAgICBpZiAoY2h1bmtCdWZmZXIpIGF1ZGlvQnVmZmVycy5wdXNoKGNodW5rQnVmZmVyKTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gQWRkIGEgc21hbGwgcGF1c2UgYmV0d2VlbiBzdG9yaWVzXG4gICAgICAgIGlmIChpbmRleCA8IHN0b3JpZXMubGVuZ3RoIC0gMSkge1xuICAgICAgICAgIGNvbnN0IHBhdXNlQnVmZmVyID0gYXdhaXQgZ2VuZXJhdGVTaW5nbGVBdWRpb0J1ZmZlcihwb2xseUNsaWVudCwgXCJOZXh0IHN0b3J5LlwiKTtcbiAgICAgICAgICBpZiAocGF1c2VCdWZmZXIpIGF1ZGlvQnVmZmVycy5wdXNoKHBhdXNlQnVmZmVyKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBcbiAgICAvLyBHZW5lcmF0ZSBvdXRyb1xuICAgIGNvbnNvbGUubG9nKCfwn461IEdlbmVyYXRpbmcgb3V0cm8gYXVkaW8uLi4nKTtcbiAgICBjb25zdCBvdXRyb1RleHQgPSBcIlRoYXQgY29uY2x1ZGVzIHRvZGF5J3MgSGFja2VyIE5ld3MgZGlnZXN0LiBUaGFuayB5b3UgZm9yIGxpc3RlbmluZy5cIjtcbiAgICBjb25zdCBvdXRyb0J1ZmZlciA9IGF3YWl0IGdlbmVyYXRlU2luZ2xlQXVkaW9CdWZmZXIocG9sbHlDbGllbnQsIG91dHJvVGV4dCk7XG4gICAgaWYgKG91dHJvQnVmZmVyKSBhdWRpb0J1ZmZlcnMucHVzaChvdXRyb0J1ZmZlcik7XG4gICAgXG4gICAgaWYgKGF1ZGlvQnVmZmVycy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gYXVkaW8gYnVmZmVycyB3ZXJlIGdlbmVyYXRlZCcpO1xuICAgIH1cbiAgICBcbiAgICAvLyBDb25jYXRlbmF0ZSBhbGwgYXVkaW8gYnVmZmVyc1xuICAgIGNvbnNvbGUubG9nKGDwn461IENvbmNhdGVuYXRpbmcgJHthdWRpb0J1ZmZlcnMubGVuZ3RofSBhdWRpbyBzZWdtZW50cy4uLmApO1xuICAgIGNvbnN0IGNvbWJpbmVkQnVmZmVyID0gQnVmZmVyLmNvbmNhdChhdWRpb0J1ZmZlcnMpO1xuICAgIFxuICAgIC8vIEdlbmVyYXRlIHVuaXF1ZSBmaWxlbmFtZSBmb3IgY29tYmluZWQgYXVkaW9cbiAgICBjb25zdCBkYXRlU3RhbXAgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgIGNvbnN0IGZpbGVuYW1lID0gYGF1ZGlvLyR7ZGF0ZVN0YW1wfS9kYWlseS1kaWdlc3QtJHtEYXRlLm5vdygpfS5tcDNgO1xuICAgIFxuICAgIC8vIFVwbG9hZCB0byBTM1xuICAgIGNvbnN0IGJ1Y2tldE5hbWUgPSBwcm9jZXNzLmVudi5BVURJT19CVUNLRVRfTkFNRTtcbiAgICBpZiAoIWJ1Y2tldE5hbWUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQVVESU9fQlVDS0VUX05BTUUgZW52aXJvbm1lbnQgdmFyaWFibGUgbm90IHNldCcpO1xuICAgIH1cblxuICAgIGNvbnN0IHVwbG9hZENvbW1hbmQgPSBuZXcgUHV0T2JqZWN0Q29tbWFuZCh7XG4gICAgICBCdWNrZXQ6IGJ1Y2tldE5hbWUsXG4gICAgICBLZXk6IGZpbGVuYW1lLFxuICAgICAgQm9keTogY29tYmluZWRCdWZmZXIsXG4gICAgICBDb250ZW50VHlwZTogJ2F1ZGlvL21wZWcnXG4gICAgfSk7XG5cbiAgICBhd2FpdCBzM0NsaWVudC5zZW5kKHVwbG9hZENvbW1hbmQpO1xuICAgIFxuICAgIGNvbnN0IGF1ZGlvVXJsID0gYGh0dHBzOi8vJHtidWNrZXROYW1lfS5zMy4ke3Byb2Nlc3MuZW52LkFXU19SRUdJT04gfHwgJ3VzLXdlc3QtMid9LmFtYXpvbmF3cy5jb20vJHtmaWxlbmFtZX1gO1xuICAgIGNvbnNvbGUubG9nKGDwn461IENvbWJpbmVkIGF1ZGlvIGdlbmVyYXRlZDogJHthdWRpb1VybH1gKTtcbiAgICBcbiAgICByZXR1cm4gYXVkaW9Vcmw7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihg4p2MIEZhaWxlZCB0byBnZW5lcmF0ZSBjb21iaW5lZCBhdWRpbzpgLCBlcnJvcik7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufVxuXG5mdW5jdGlvbiBzcGxpdFRleHRJbnRvQ2h1bmtzKHRleHQ6IHN0cmluZywgbWF4Q2h1bmtTaXplOiBudW1iZXIpOiBzdHJpbmdbXSB7XG4gIGlmICh0ZXh0Lmxlbmd0aCA8PSBtYXhDaHVua1NpemUpIHtcbiAgICByZXR1cm4gW3RleHRdO1xuICB9XG4gIFxuICBjb25zdCBjaHVua3M6IHN0cmluZ1tdID0gW107XG4gIGxldCBjdXJyZW50Q2h1bmsgPSAnJztcbiAgXG4gIC8vIFNwbGl0IGJ5IHNlbnRlbmNlcyB0byBtYWludGFpbiBuYXR1cmFsIGJyZWFrc1xuICBjb25zdCBzZW50ZW5jZXMgPSB0ZXh0LnNwbGl0KC9bLiE/XSsvKS5maWx0ZXIocyA9PiBzLnRyaW0oKS5sZW5ndGggPiAwKTtcbiAgXG4gIGZvciAoY29uc3Qgc2VudGVuY2Ugb2Ygc2VudGVuY2VzKSB7XG4gICAgY29uc3QgdHJpbW1lZFNlbnRlbmNlID0gc2VudGVuY2UudHJpbSgpO1xuICAgIGlmICghdHJpbW1lZFNlbnRlbmNlKSBjb250aW51ZTtcbiAgICBcbiAgICBjb25zdCBzZW50ZW5jZVdpdGhQdW5jdHVhdGlvbiA9IHRyaW1tZWRTZW50ZW5jZSArICcuJztcbiAgICBcbiAgICAvLyBJZiBhZGRpbmcgdGhpcyBzZW50ZW5jZSB3b3VsZCBleGNlZWQgdGhlIGxpbWl0LCBzYXZlIGN1cnJlbnQgY2h1bmsgYW5kIHN0YXJ0IG5ldyBvbmVcbiAgICBpZiAoY3VycmVudENodW5rLmxlbmd0aCArIHNlbnRlbmNlV2l0aFB1bmN0dWF0aW9uLmxlbmd0aCArIDEgPiBtYXhDaHVua1NpemUpIHtcbiAgICAgIGlmIChjdXJyZW50Q2h1bmsudHJpbSgpKSB7XG4gICAgICAgIGNodW5rcy5wdXNoKGN1cnJlbnRDaHVuay50cmltKCkpO1xuICAgICAgfVxuICAgICAgY3VycmVudENodW5rID0gc2VudGVuY2VXaXRoUHVuY3R1YXRpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1cnJlbnRDaHVuayArPSAoY3VycmVudENodW5rID8gJyAnIDogJycpICsgc2VudGVuY2VXaXRoUHVuY3R1YXRpb247XG4gICAgfVxuICB9XG4gIFxuICAvLyBBZGQgdGhlIGxhc3QgY2h1bmsgaWYgaXQgaGFzIGNvbnRlbnRcbiAgaWYgKGN1cnJlbnRDaHVuay50cmltKCkpIHtcbiAgICBjaHVua3MucHVzaChjdXJyZW50Q2h1bmsudHJpbSgpKTtcbiAgfVxuICBcbiAgcmV0dXJuIGNodW5rcy5sZW5ndGggPiAwID8gY2h1bmtzIDogW3RleHRdOyAvLyBGYWxsYmFjayB0byBvcmlnaW5hbCB0ZXh0IGlmIG5vIGNodW5rcyBjcmVhdGVkXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlU2luZ2xlQXVkaW9CdWZmZXIocG9sbHlDbGllbnQ6IFBvbGx5Q2xpZW50LCB0ZXh0OiBzdHJpbmcpOiBQcm9taXNlPEJ1ZmZlciB8IG51bGw+IHtcbiAgdHJ5IHtcbiAgICAvLyBFbnN1cmUgdGV4dCBpcyB3aXRoaW4gUG9sbHkncyBsaW1pdHMgKDMwMDAgY2hhcmFjdGVycylcbiAgICBjb25zdCB0cnVuY2F0ZWRUZXh0ID0gdGV4dC5sZW5ndGggPiAyODAwID8gdGV4dC5zdWJzdHJpbmcoMCwgMjgwMCkgKyBcIi4uLlwiIDogdGV4dDtcbiAgICBcbiAgICBjb25zdCBzeW50aGVzaXplQ29tbWFuZCA9IG5ldyBTeW50aGVzaXplU3BlZWNoQ29tbWFuZCh7XG4gICAgICBUZXh0OiB0cnVuY2F0ZWRUZXh0LFxuICAgICAgT3V0cHV0Rm9ybWF0OiAnbXAzJyxcbiAgICAgIFZvaWNlSWQ6ICdKb2FubmEnLFxuICAgICAgRW5naW5lOiAnbmV1cmFsJ1xuICAgIH0pO1xuXG4gICAgY29uc3QgcG9sbHlSZXNwb25zZSA9IGF3YWl0IHBvbGx5Q2xpZW50LnNlbmQoc3ludGhlc2l6ZUNvbW1hbmQpO1xuICAgIFxuICAgIGlmICghcG9sbHlSZXNwb25zZS5BdWRpb1N0cmVhbSkge1xuICAgICAgY29uc29sZS5lcnJvcignTm8gYXVkaW8gc3RyZWFtIHJlY2VpdmVkIGZyb20gUG9sbHknKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCBzdHJlYW1Ub0J1ZmZlcihwb2xseVJlc3BvbnNlLkF1ZGlvU3RyZWFtKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKGDinYwgRmFpbGVkIHRvIGdlbmVyYXRlIHNpbmdsZSBhdWRpbyBidWZmZXI6YCwgZXJyb3IpO1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0cmVhbVRvQnVmZmVyKHN0cmVhbTogYW55KTogUHJvbWlzZTxCdWZmZXI+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCBjaHVua3M6IEJ1ZmZlcltdID0gW107XG4gICAgXG4gICAgc3RyZWFtLm9uKCdkYXRhJywgKGNodW5rOiBCdWZmZXIpID0+IHtcbiAgICAgIGNodW5rcy5wdXNoKGNodW5rKTtcbiAgICB9KTtcbiAgICBcbiAgICBzdHJlYW0ub24oJ2VuZCcsICgpID0+IHtcbiAgICAgIHJlc29sdmUoQnVmZmVyLmNvbmNhdChjaHVua3MpKTtcbiAgICB9KTtcbiAgICBcbiAgICBzdHJlYW0ub24oJ2Vycm9yJywgKGVycm9yOiBFcnJvcikgPT4ge1xuICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICB9KTtcbiAgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNhdmVEYWlseVJlY29tbWVuZGF0aW9ucyhcbiAgc3RvcmllczogU3RvcnlJbmZvW10sIFxuICB0aW1lc3RhbXA6IHN0cmluZywgXG4gIGNvbWJpbmVkQXVkaW9Vcmw/OiBzdHJpbmdcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBkeW5hbW9DbGllbnQgPSBuZXcgRHluYW1vREJDbGllbnQoeyBcbiAgICByZWdpb246IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfHwgJ3VzLXdlc3QtMicgXG4gIH0pO1xuICBcbiAgY29uc3QgZG9jQ2xpZW50ID0gRHluYW1vREJEb2N1bWVudENsaWVudC5mcm9tKGR5bmFtb0NsaWVudCk7XG4gIGNvbnN0IHRhYmxlTmFtZSA9IHByb2Nlc3MuZW52LlJFQ09NTUVOREFUSU9OU19UQUJMRV9OQU1FO1xuICBcbiAgaWYgKCF0YWJsZU5hbWUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1JFQ09NTUVOREFUSU9OU19UQUJMRV9OQU1FIGVudmlyb25tZW50IHZhcmlhYmxlIG5vdCBzZXQnKTtcbiAgfVxuXG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh0aW1lc3RhbXApLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTsgLy8gWVlZWS1NTS1ERCBmb3JtYXRcbiAgY29uc3Qgb25lWWVhckZyb21Ob3cgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKSArICgzNjUgKiAyNCAqIDYwICogNjApOyAvLyBUVEwgaW4gc2Vjb25kc1xuXG4gIGNvbnNvbGUubG9nKGDwn5K+IFNhdmluZyAke3N0b3JpZXMubGVuZ3RofSByZWNvbW1lbmRhdGlvbnMgZm9yIGRhdGU6ICR7ZGF0ZX1gKTtcblxuICAvLyBTYXZlIGluZGl2aWR1YWwgc3RvcnkgcmVjb21tZW5kYXRpb25zXG4gIGNvbnN0IHB1dFJlcXVlc3RzID0gc3Rvcmllcy5tYXAoKHN0b3J5LCBpbmRleCkgPT4gKHtcbiAgICBQdXRSZXF1ZXN0OiB7XG4gICAgICBJdGVtOiB7XG4gICAgICAgIGlkOiBgJHtzdG9yeS5zb3VyY2V9LSR7aW5kZXh9LSR7RGF0ZS5ub3coKX1gLCAvLyBVbmlxdWUgSUQgZm9yIGVhY2ggc3RvcnkgKHByaW1hcnkga2V5KVxuICAgICAgICBkYXRlOiBkYXRlLFxuICAgICAgICBzb3VyY2U6IHN0b3J5LnNvdXJjZSxcbiAgICAgICAgdGl0bGU6IHN0b3J5LnRpdGxlLFxuICAgICAgICB1cmw6IHN0b3J5LnVybCxcbiAgICAgICAgc2NvcmU6IHN0b3J5LnNjb3JlLFxuICAgICAgICBhdXRob3I6IHN0b3J5LmF1dGhvcixcbiAgICAgICAgY29tbWVudHM6IHN0b3J5LmNvbW1lbnRzLFxuICAgICAgICB0aW1lc3RhbXA6IHN0b3J5LnRpbWVzdGFtcCxcbiAgICAgICAgc3VtbWFyeTogc3Rvcnkuc3VtbWFyeSB8fCAnJyxcbiAgICAgICAgYXVkaW9Vcmw6IHN0b3J5LmF1ZGlvVXJsIHx8ICcnLFxuICAgICAgICB0dGw6IG9uZVllYXJGcm9tTm93XG4gICAgICB9IGFzIERhaWx5UmVjb21tZW5kYXRpb25cbiAgICB9XG4gIH0pKTtcblxuICAvLyBTYXZlIGRhaWx5IGRpZ2VzdCBtZXRhZGF0YVxuICBjb25zdCBkaWdlc3RSZWNvcmQ6IERhaWx5RGlnZXN0ID0ge1xuICAgIGlkOiBgZGlnZXN0LSR7ZGF0ZX1gLCAvLyBVbmlxdWUgZGlnZXN0IElEIChwcmltYXJ5IGtleSlcbiAgICBkYXRlOiBkYXRlLFxuICAgIHNvdXJjZTogJ2RhaWx5LWRpZ2VzdCcsXG4gICAgdG90YWxTdG9yaWVzOiBzdG9yaWVzLmxlbmd0aCxcbiAgICB0aW1lc3RhbXA6IHRpbWVzdGFtcCxcbiAgICBjb21iaW5lZEF1ZGlvVXJsOiBjb21iaW5lZEF1ZGlvVXJsIHx8ICcnLFxuICAgIGVtYWlsU2VudDogZmFsc2UsIC8vIFdpbGwgYmUgdXBkYXRlZCBhZnRlciBlbWFpbCBpcyBzZW50XG4gICAgdHRsOiBvbmVZZWFyRnJvbU5vd1xuICB9O1xuXG4gIHRyeSB7XG4gICAgLy8gQmF0Y2ggd3JpdGUgaW5kaXZpZHVhbCByZWNvbW1lbmRhdGlvbnMgKG1heCAyNSBpdGVtcyBwZXIgYmF0Y2gpXG4gICAgY29uc3QgYmF0Y2hlcyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHV0UmVxdWVzdHMubGVuZ3RoOyBpICs9IDI1KSB7XG4gICAgICBiYXRjaGVzLnB1c2gocHV0UmVxdWVzdHMuc2xpY2UoaSwgaSArIDI1KSk7XG4gICAgfVxuXG4gICAgZm9yIChjb25zdCBiYXRjaCBvZiBiYXRjaGVzKSB7XG4gICAgICBjb25zdCBiYXRjaFdyaXRlQ29tbWFuZCA9IG5ldyBCYXRjaFdyaXRlQ29tbWFuZCh7XG4gICAgICAgIFJlcXVlc3RJdGVtczoge1xuICAgICAgICAgIFt0YWJsZU5hbWVdOiBiYXRjaFxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGRvY0NsaWVudC5zZW5kKGJhdGNoV3JpdGVDb21tYW5kKTtcbiAgICB9XG5cbiAgICAvLyBTYXZlIGRpZ2VzdCByZWNvcmRcbiAgICBjb25zdCBwdXREaWdlc3RDb21tYW5kID0gbmV3IFB1dENvbW1hbmQoe1xuICAgICAgVGFibGVOYW1lOiB0YWJsZU5hbWUsXG4gICAgICBJdGVtOiBkaWdlc3RSZWNvcmRcbiAgICB9KTtcbiAgICBhd2FpdCBkb2NDbGllbnQuc2VuZChwdXREaWdlc3RDb21tYW5kKTtcblxuICAgIGNvbnNvbGUubG9nKGDinIUgU3VjY2Vzc2Z1bGx5IHNhdmVkICR7c3Rvcmllcy5sZW5ndGh9IHJlY29tbWVuZGF0aW9ucyBhbmQgZGlnZXN0IGZvciAke2RhdGV9YCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcign4p2MIEZhaWxlZCB0byBzYXZlIHJlY29tbWVuZGF0aW9ucyB0byBkYXRhYmFzZTonLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gdXBkYXRlRW1haWxTZW50U3RhdHVzKHRpbWVzdGFtcDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGR5bmFtb0NsaWVudCA9IG5ldyBEeW5hbW9EQkNsaWVudCh7IFxuICAgIHJlZ2lvbjogcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtd2VzdC0yJyBcbiAgfSk7XG4gIFxuICBjb25zdCBkb2NDbGllbnQgPSBEeW5hbW9EQkRvY3VtZW50Q2xpZW50LmZyb20oZHluYW1vQ2xpZW50KTtcbiAgY29uc3QgdGFibGVOYW1lID0gcHJvY2Vzcy5lbnYuUkVDT01NRU5EQVRJT05TX1RBQkxFX05BTUU7XG4gIFxuICBpZiAoIXRhYmxlTmFtZSkge1xuICAgIHRocm93IG5ldyBFcnJvcignUkVDT01NRU5EQVRJT05TX1RBQkxFX05BTUUgZW52aXJvbm1lbnQgdmFyaWFibGUgbm90IHNldCcpO1xuICB9XG5cbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKHRpbWVzdGFtcCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgcHV0Q29tbWFuZCA9IG5ldyBQdXRDb21tYW5kKHtcbiAgICAgIFRhYmxlTmFtZTogdGFibGVOYW1lLFxuICAgICAgSXRlbToge1xuICAgICAgICBpZDogYGRpZ2VzdC0ke2RhdGV9YCxcbiAgICAgICAgZW1haWxTZW50OiB0cnVlLFxuICAgICAgICBsYXN0VXBkYXRlZDogdGltZXN0YW1wXG4gICAgICB9LFxuICAgICAgQ29uZGl0aW9uRXhwcmVzc2lvbjogJ2F0dHJpYnV0ZV9leGlzdHMoI2lkKScsXG4gICAgICBFeHByZXNzaW9uQXR0cmlidXRlTmFtZXM6IHtcbiAgICAgICAgJyNpZCc6ICdpZCdcbiAgICAgIH1cbiAgICB9KTtcbiAgICBcbiAgICBhd2FpdCBkb2NDbGllbnQuc2VuZChwdXRDb21tYW5kKTtcbiAgICBjb25zb2xlLmxvZyhg4pyFIFVwZGF0ZWQgZW1haWwgc2VudCBzdGF0dXMgZm9yICR7ZGF0ZX1gKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCfinYwgRmFpbGVkIHRvIHVwZGF0ZSBlbWFpbCBzZW50IHN0YXR1czonLCBlcnJvcik7XG4gICAgLy8gRG9uJ3QgdGhyb3cgZXJyb3IgaGVyZSBhcyBpdCdzIG5vdCBjcml0aWNhbFxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNlbmRFbWFpbFN1bW1hcnkobmV3c2xldHRlckRhdGE6IE5ld3NsZXR0ZXJEYXRhLCB0aW1lc3RhbXA6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXNDbGllbnQgPSBuZXcgU0VTQ2xpZW50KHsgXG4gICAgcmVnaW9uOiBwcm9jZXNzLmVudi5BV1NfUkVHSU9OIHx8ICd1cy13ZXN0LTInIFxuICB9KTtcblxuICAvLyBDcmVhdGUgSFRNTCBlbWFpbCBjb250ZW50XG4gIGNvbnN0IGh0bWxDb250ZW50ID0gZ2VuZXJhdGVFbWFpbEhUTUwobmV3c2xldHRlckRhdGEsIHRpbWVzdGFtcCk7XG4gIGNvbnN0IHRleHRDb250ZW50ID0gZ2VuZXJhdGVFbWFpbFRleHQobmV3c2xldHRlckRhdGEsIHRpbWVzdGFtcCk7XG5cbiAgY29uc3QgcGFyYW1zID0ge1xuICAgIERlc3RpbmF0aW9uOiB7XG4gICAgICBUb0FkZHJlc3NlczogWyd4a2V2aW5qQGdtYWlsLmNvbSddXG4gICAgfSxcbiAgICBNZXNzYWdlOiB7XG4gICAgICBCb2R5OiB7XG4gICAgICAgIEh0bWw6IHtcbiAgICAgICAgICBDaGFyc2V0OiAnVVRGLTgnLFxuICAgICAgICAgIERhdGE6IGh0bWxDb250ZW50XG4gICAgICAgIH0sXG4gICAgICAgIFRleHQ6IHtcbiAgICAgICAgICBDaGFyc2V0OiAnVVRGLTgnLFxuICAgICAgICAgIERhdGE6IHRleHRDb250ZW50XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBTdWJqZWN0OiB7XG4gICAgICAgIENoYXJzZXQ6ICdVVEYtOCcsXG4gICAgICAgIERhdGE6IGDwn5OwIEhhY2tlciBOZXdzIFN1bW1hcnkgLSAke25ldyBEYXRlKHRpbWVzdGFtcCkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9YFxuICAgICAgfVxuICAgIH0sXG4gICAgU291cmNlOiBwcm9jZXNzLmVudi5TRVNfRlJPTV9FTUFJTCB8fCAnbmV3c2FnZW50QGV4YW1wbGUuY29tJyAvLyBZb3UnbGwgbmVlZCB0byB2ZXJpZnkgdGhpcyBlbWFpbCBpbiBTRVNcbiAgfTtcblxuICBjb25zdCBjb21tYW5kID0gbmV3IFNlbmRFbWFpbENvbW1hbmQocGFyYW1zKTtcbiAgYXdhaXQgc2VzQ2xpZW50LnNlbmQoY29tbWFuZCk7XG4gIFxuICAvLyBVcGRhdGUgZGF0YWJhc2Ugd2l0aCBlbWFpbCBzZW50IHN0YXR1c1xuICB0cnkge1xuICAgIGF3YWl0IHVwZGF0ZUVtYWlsU2VudFN0YXR1cyh0aW1lc3RhbXApO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ+KdjCBGYWlsZWQgdG8gdXBkYXRlIGVtYWlsIHNlbnQgc3RhdHVzIGluIGRhdGFiYXNlOicsIGVycm9yKTtcbiAgICAvLyBEb24ndCBmYWlsIHRoZSBlbWFpbCBzZW5kIGZvciB0aGlzXG4gIH1cbn1cblxuZnVuY3Rpb24gZ2VuZXJhdGVFbWFpbEhUTUwobmV3c2xldHRlckRhdGE6IE5ld3NsZXR0ZXJEYXRhLCB0aW1lc3RhbXA6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh0aW1lc3RhbXApLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tVVMnLCB7XG4gICAgd2Vla2RheTogJ2xvbmcnLFxuICAgIHllYXI6ICdudW1lcmljJyxcbiAgICBtb250aDogJ2xvbmcnLFxuICAgIGRheTogJ251bWVyaWMnLFxuICAgIGhvdXI6ICcyLWRpZ2l0JyxcbiAgICBtaW51dGU6ICcyLWRpZ2l0JyxcbiAgICB0aW1lWm9uZU5hbWU6ICdzaG9ydCdcbiAgfSk7XG5cbiAgLy8gQWRkIFwiUGxheSBBbGxcIiBidXR0b24gaWYgY29tYmluZWQgYXVkaW8gaXMgYXZhaWxhYmxlXG4gIGxldCBwbGF5QWxsU2VjdGlvbiA9ICcnO1xuICBpZiAobmV3c2xldHRlckRhdGEuY29tYmluZWRBdWRpb1VybCkge1xuICAgIHBsYXlBbGxTZWN0aW9uID0gYFxuICAgICAgPGRpdiBzdHlsZT1cIm1hcmdpbi1ib3R0b206IDMwcHg7IHBhZGRpbmc6IDIwcHg7IGJhY2tncm91bmQtY29sb3I6ICNmMGY4ZmY7IGJvcmRlci1yYWRpdXM6IDhweDsgdGV4dC1hbGlnbjogY2VudGVyOyBib3JkZXI6IDJweCBzb2xpZCAjZmY2NjAwO1wiPlxuICAgICAgICA8aDIgc3R5bGU9XCJjb2xvcjogI2ZmNjYwMDsgZm9udC1zaXplOiAyMHB4OyBtYXJnaW46IDAgMCAxNXB4IDA7XCI+8J+OpyBMaXN0ZW4gdG8gQWxsIFN0b3JpZXM8L2gyPlxuICAgICAgICA8YSBocmVmPVwiJHtuZXdzbGV0dGVyRGF0YS5jb21iaW5lZEF1ZGlvVXJsfVwiIHN0eWxlPVwiZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiAxNXB4IDMwcHg7IGJhY2tncm91bmQtY29sb3I6ICNmZjY2MDA7IGNvbG9yOiB3aGl0ZTsgdGV4dC1kZWNvcmF0aW9uOiBub25lOyBib3JkZXItcmFkaXVzOiA4cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBmb250LXNpemU6IDE2cHg7IGJveC1zaGFkb3c6IDAgNHB4IDhweCByZ2JhKDI1NSwxMDIsMCwwLjMpO1wiPlxuICAgICAgICAgIPCfjrUgUGxheSBGdWxsIERhaWx5IERpZ2VzdFxuICAgICAgICA8L2E+XG4gICAgICAgIDxwIHN0eWxlPVwibWFyZ2luOiAxMHB4IDAgMCAwOyBmb250LXNpemU6IDE0cHg7IGNvbG9yOiAjNjY2O1wiPkxpc3RlbiB0byBhbGwgJHtuZXdzbGV0dGVyRGF0YS5zdG9yaWVzLmxlbmd0aH0gc3Rvcnkgc3VtbWFyaWVzIGluIG9uZSBjb250aW51b3VzIGF1ZGlvPC9wPlxuICAgICAgPC9kaXY+YDtcbiAgfVxuXG4gIGxldCBzdG9yaWVzSFRNTCA9ICcnO1xuICBuZXdzbGV0dGVyRGF0YS5zdG9yaWVzLmZvckVhY2goKHN0b3J5LCBpbmRleCkgPT4ge1xuICAgICAgbGV0IHNvdXJjZUljb24sIHNvdXJjZUNvbG9yLCBzb3VyY2VOYW1lO1xuICAgICAgaWYgKHN0b3J5LnNvdXJjZSA9PT0gJ2hhY2tlci1uZXdzJykge1xuICAgICAgICBzb3VyY2VJY29uID0gJ/Cfk7AnO1xuICAgICAgICBzb3VyY2VDb2xvciA9ICcjZmY2NjAwJztcbiAgICAgICAgc291cmNlTmFtZSA9ICdIYWNrZXIgTmV3cyc7XG4gICAgICB9IGVsc2UgaWYgKHN0b3J5LnNvdXJjZSA9PT0gJ3Byb2R1Y3QtaHVudCcpIHtcbiAgICAgICAgc291cmNlSWNvbiA9ICfwn4+GJztcbiAgICAgICAgc291cmNlQ29sb3IgPSAnI2RhNTUyZic7XG4gICAgICAgIHNvdXJjZU5hbWUgPSAnUHJvZHVjdCBIdW50JztcbiAgICAgIH0gZWxzZSBpZiAoc3Rvcnkuc291cmNlID09PSAnZ2l0aHViLXRyZW5kaW5nJykge1xuICAgICAgICBzb3VyY2VJY29uID0gJ+KtkCc7XG4gICAgICAgIHNvdXJjZUNvbG9yID0gJyMyNDI5MmUnO1xuICAgICAgICBzb3VyY2VOYW1lID0gJ0dpdEh1YiBUcmVuZGluZyc7XG4gICAgICB9XG4gICAgICBcbiAgICBzdG9yaWVzSFRNTCArPSBgXG4gICAgICAgIDxkaXYgc3R5bGU9XCJtYXJnaW4tYm90dG9tOiAyNXB4OyBwYWRkaW5nOiAxNXB4OyBiYWNrZ3JvdW5kLWNvbG9yOiAjZjlmOWY5OyBib3JkZXItbGVmdDogNHB4IHNvbGlkICR7c291cmNlQ29sb3J9O1wiPlxuICAgICAgICAgIDxkaXYgc3R5bGU9XCJkaXNwbGF5OiBmbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBtYXJnaW4tYm90dG9tOiA4cHg7XCI+XG4gICAgICAgICAgICA8c3BhbiBzdHlsZT1cImJhY2tncm91bmQtY29sb3I6ICR7c291cmNlQ29sb3J9OyBjb2xvcjogd2hpdGU7IHBhZGRpbmc6IDRweCA4cHg7IGJvcmRlci1yYWRpdXM6IDEycHg7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IGJvbGQ7IG1hcmdpbi1yaWdodDogMTBweDtcIj5cbiAgICAgICAgICAgICAgJHtzb3VyY2VJY29ufSAke3NvdXJjZU5hbWV9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDxoMyBzdHlsZT1cIm1hcmdpbjogMCAwIDEwcHggMDsgY29sb3I6ICMzMzM7XCI+XG4gICAgICAgICAgICAke2luZGV4ICsgMX0uIDxhIGhyZWY9XCIke3N0b3J5LnVybH1cIiBzdHlsZT1cImNvbG9yOiAke3NvdXJjZUNvbG9yfTsgdGV4dC1kZWNvcmF0aW9uOiBub25lO1wiPiR7c3RvcnkudGl0bGV9PC9hPlxuICAgICAgICA8L2gzPlxuICAgICAgICA8cCBzdHlsZT1cIm1hcmdpbjogNXB4IDA7IGNvbG9yOiAjODg4OyBmb250LXNpemU6IDEycHg7XCI+XG4gICAgICAgICAg8J+VkCBQb3N0ZWQ6ICR7bmV3IERhdGUoc3RvcnkudGltZXN0YW1wKS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgIDwvcD5gO1xuICAgIFxuICAgIGlmIChzdG9yeS5zdW1tYXJ5KSB7XG4gICAgICAvLyBDb252ZXJ0IG1hcmtkb3duIHRvIEhUTUwgZm9yIGJldHRlciByZW5kZXJpbmdcbiAgICAgIGNvbnN0IGh0bWxTdW1tYXJ5ID0gc3Rvcnkuc3VtbWFyeVxuICAgICAgICAucmVwbGFjZSgvXiMrXFxzKi9nbSwgJycpIC8vIFJlbW92ZSBhbGwgbWFya2Rvd24gaGVhZGVycyAoIyAjIyAjIyMgZXRjKVxuICAgICAgICAucmVwbGFjZSgvXFwqXFwqKC4qPylcXCpcXCovZywgJzxzdHJvbmc+JDE8L3N0cm9uZz4nKVxuICAgICAgICAucmVwbGFjZSgvXFwqKC4qPylcXCovZywgJzxlbT4kMTwvZW0+JylcbiAgICAgICAgLnJlcGxhY2UoL15cXGQrXFwuICguKikvZ20sICc8ZGl2IHN0eWxlPVwibWFyZ2luOiA4cHggMDsgcGFkZGluZy1sZWZ0OiAxNXB4O1wiPjxzdHJvbmc+4oCiICQxPC9zdHJvbmc+PC9kaXY+JylcbiAgICAgICAgLnJlcGxhY2UoL1xcblxcbi9nLCAnPC9wPjxwIHN0eWxlPVwibWFyZ2luOiA4cHggMDsgbGluZS1oZWlnaHQ6IDEuNjtcIj4nKVxuICAgICAgICAucmVwbGFjZSgvXFxuL2csICc8YnI+Jyk7XG4gICAgICBcbiAgICAgIHN0b3JpZXNIVE1MICs9IGBcbiAgICAgICAgPGRpdiBzdHlsZT1cIm1hcmdpbi10b3A6IDE1cHg7IHBhZGRpbmc6IDIwcHg7IGJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDZweDsgYm94LXNoYWRvdzogMCAycHggNHB4IHJnYmEoMCwwLDAsMC4xKTtcIj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPVwiY29sb3I6ICM0NDQ7IGZvbnQtc2l6ZTogMTRweDsgbGluZS1oZWlnaHQ6IDEuNjtcIj5cbiAgICAgICAgICAgIDxwIHN0eWxlPVwibWFyZ2luOiA4cHggMDsgbGluZS1oZWlnaHQ6IDEuNjtcIj4ke2h0bWxTdW1tYXJ5fTwvcD5cbiAgICAgICAgICA8L2Rpdj5gO1xuICAgICAgXG4gICAgICBcbiAgICAgIHN0b3JpZXNIVE1MICs9IGBcbiAgICAgICAgPC9kaXY+YDtcbiAgICB9XG4gICAgXG4gICAgc3Rvcmllc0hUTUwgKz0gYFxuICAgICAgPC9kaXY+XG4gICAgYDtcbiAgfSk7XG5cbiAgcmV0dXJuIGBcbiAgICA8IURPQ1RZUEUgaHRtbD5cbiAgICA8aHRtbD5cbiAgICA8aGVhZD5cbiAgICAgICAgPG1ldGEgY2hhcnNldD1cIlVURi04XCI+XG4gICAgICAgIDx0aXRsZT5IYWNrZXIgTmV3cyBTdW1tYXJ5PC90aXRsZT5cbiAgICA8L2hlYWQ+XG4gICAgPGJvZHkgc3R5bGU9XCJmb250LWZhbWlseTogQXJpYWwsIHNhbnMtc2VyaWY7IGxpbmUtaGVpZ2h0OiAxLjY7IGNvbG9yOiAjMzMzOyBtYXgtd2lkdGg6IDYwMHB4OyBtYXJnaW46IDAgYXV0bzsgcGFkZGluZzogMjBweDtcIj5cbiAgICAgICAgPGRpdiBzdHlsZT1cInRleHQtYWxpZ246IGNlbnRlcjsgbWFyZ2luLWJvdHRvbTogMzBweDsgcGFkZGluZzogMjBweDsgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgI2ZmNjYwMCwgI2RhNTUyZik7IGNvbG9yOiB3aGl0ZTsgYm9yZGVyLXJhZGl1czogOHB4O1wiPlxuICAgICAgICAgICAgPGgxIHN0eWxlPVwibWFyZ2luOiAwO1wiPvCfmoAgRGFpbHkgVGVjaCBEaWdlc3Q8L2gxPlxuICAgICAgICAgICAgPHAgc3R5bGU9XCJtYXJnaW46IDEwcHggMCAwIDA7XCI+SGFja2VyIE5ld3Mg4oCiIFByb2R1Y3QgSHVudCDigKIgR2l0SHViIFRyZW5kaW5nPC9wPlxuICAgICAgICAgICAgPHAgc3R5bGU9XCJtYXJnaW46IDVweCAwIDAgMDsgZm9udC1zaXplOiAxNHB4O1wiPiR7ZGF0ZX08L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICBcbiAgICAgICAgJHtwbGF5QWxsU2VjdGlvbn1cbiAgICAgICAgXG4gICAgICAgIDxkaXYgc3R5bGU9XCJtYXJnaW4tYm90dG9tOiAyMHB4O1wiPlxuICAgICAgICAgICAgPGgyIHN0eWxlPVwiY29sb3I6ICNmZjY2MDA7XCI+8J+UpSBUb3AgJHtuZXdzbGV0dGVyRGF0YS5zdG9yaWVzLmxlbmd0aH0gU3RvcmllczwvaDI+XG4gICAgICAgICAgICAke3N0b3JpZXNIVE1MfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgXG4gICAgICAgIDxkaXYgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7IG1hcmdpbi10b3A6IDMwcHg7IHBhZGRpbmc6IDE1cHg7IGJhY2tncm91bmQtY29sb3I6ICNmMGYwZjA7IGJvcmRlci1yYWRpdXM6IDZweDsgZm9udC1zaXplOiAxMnB4OyBjb2xvcjogIzY2NjtcIj5cbiAgICAgICAgICAgIDxwPlRoaXMgc3VtbWFyeSB3YXMgYXV0b21hdGljYWxseSBnZW5lcmF0ZWQgYnkgeW91ciBOZXdzQWdlbnQgTGFtYmRhIGZ1bmN0aW9uLjwvcD5cbiAgICAgICAgICAgIDxwPvCfpJYgUG93ZXJlZCBieSBBV1MgTGFtYmRhLCBCZWRyb2NrICYgSGFja2VyIE5ld3MgQVBJPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICA8L2JvZHk+XG4gICAgPC9odG1sPlxuICBgO1xufVxuXG5mdW5jdGlvbiBnZW5lcmF0ZUVtYWlsVGV4dChuZXdzbGV0dGVyRGF0YTogTmV3c2xldHRlckRhdGEsIHRpbWVzdGFtcDogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKHRpbWVzdGFtcCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1VUycsIHtcbiAgICB3ZWVrZGF5OiAnbG9uZycsXG4gICAgeWVhcjogJ251bWVyaWMnLFxuICAgIG1vbnRoOiAnbG9uZycsXG4gICAgZGF5OiAnbnVtZXJpYycsXG4gICAgaG91cjogJzItZGlnaXQnLFxuICAgIG1pbnV0ZTogJzItZGlnaXQnLFxuICAgIHRpbWVab25lTmFtZTogJ3Nob3J0J1xuICB9KTtcblxuICAvLyBBZGQgXCJQbGF5IEFsbFwiIGJ1dHRvbiBpZiBjb21iaW5lZCBhdWRpbyBpcyBhdmFpbGFibGVcbiAgbGV0IHBsYXlBbGxUZXh0ID0gJyc7XG4gIGlmIChuZXdzbGV0dGVyRGF0YS5jb21iaW5lZEF1ZGlvVXJsKSB7XG4gICAgcGxheUFsbFRleHQgPSBgXG7wn46nIExJU1RFTiBUTyBBTEwgU1RPUklFU1xuUGxheSBGdWxsIERhaWx5IERpZ2VzdDogJHtuZXdzbGV0dGVyRGF0YS5jb21iaW5lZEF1ZGlvVXJsfVxuTGlzdGVuIHRvIGFsbCAke25ld3NsZXR0ZXJEYXRhLnN0b3JpZXMubGVuZ3RofSBzdG9yeSBzdW1tYXJpZXMgaW4gb25lIGNvbnRpbnVvdXMgYXVkaW9cblxuLS0tXG5cbmA7XG4gIH1cblxuICBsZXQgc3Rvcmllc1RleHQgPSAnJztcbiAgbmV3c2xldHRlckRhdGEuc3Rvcmllcy5mb3JFYWNoKChzdG9yeSwgaW5kZXgpID0+IHtcbiAgICBsZXQgc291cmNlTGFiZWw7XG4gICAgaWYgKHN0b3J5LnNvdXJjZSA9PT0gJ2hhY2tlci1uZXdzJykge1xuICAgICAgc291cmNlTGFiZWwgPSAn8J+TsCBIYWNrZXIgTmV3cyc7XG4gICAgfSBlbHNlIGlmIChzdG9yeS5zb3VyY2UgPT09ICdwcm9kdWN0LWh1bnQnKSB7XG4gICAgICBzb3VyY2VMYWJlbCA9ICfwn4+GIFByb2R1Y3QgSHVudCc7XG4gICAgfSBlbHNlIGlmIChzdG9yeS5zb3VyY2UgPT09ICdnaXRodWItdHJlbmRpbmcnKSB7XG4gICAgICBzb3VyY2VMYWJlbCA9ICfirZAgR2l0SHViIFRyZW5kaW5nJztcbiAgICB9XG4gICAgc3Rvcmllc1RleHQgKz0gYFxuJHtpbmRleCArIDF9LiAke3N0b3J5LnRpdGxlfSBbJHtzb3VyY2VMYWJlbH1dXG4gICBVUkw6ICR7c3RvcnkudXJsfVxuICAgUG9zdGVkOiAke25ldyBEYXRlKHN0b3J5LnRpbWVzdGFtcCkudG9Mb2NhbGVTdHJpbmcoKX1gO1xuICAgIFxuICAgIGlmIChzdG9yeS5zdW1tYXJ5KSB7XG4gICAgICAvLyBDbGVhbiB1cCBtYXJrZG93biBmb3IgcGxhaW4gdGV4dCBlbWFpbFxuICAgICAgY29uc3QgY2xlYW5TdW1tYXJ5ID0gc3Rvcnkuc3VtbWFyeVxuICAgICAgICAucmVwbGFjZSgvXiMrXFxzKi9nbSwgJycpIC8vIFJlbW92ZSBhbGwgbWFya2Rvd24gaGVhZGVyc1xuICAgICAgICAucmVwbGFjZSgvXFwqXFwqKC4qPylcXCpcXCovZywgJyQxJylcbiAgICAgICAgLnJlcGxhY2UoL1xcKiguKj8pXFwqL2csICckMScpXG4gICAgICAgIC5yZXBsYWNlKC9eXFxkK1xcLiAvZ20sICcgICDihpIgJyk7XG4gICAgICBcbiAgICAgIHN0b3JpZXNUZXh0ICs9IGBcbiAgIFxuJHtjbGVhblN1bW1hcnl9YDtcbiAgICB9XG4gICAgXG4gICAgc3Rvcmllc1RleHQgKz0gYFxuXG5gO1xuICB9KTtcblxuICByZXR1cm4gYFxuREFJTFkgVEVDSCBESUdFU1RcbkhhY2tlciBOZXdzIOKAoiBQcm9kdWN0IEh1bnQg4oCiIEdpdEh1YiBUcmVuZGluZ1xuR2VuZXJhdGVkIGJ5IE5ld3NBZ2VudCB3aXRoIEFJIFN1bW1hcmllc1xuJHtkYXRlfVxuXG4ke3BsYXlBbGxUZXh0fVRvcCAke25ld3NsZXR0ZXJEYXRhLnN0b3JpZXMubGVuZ3RofSBJdGVtczpcbiR7c3Rvcmllc1RleHR9XG4tLS1cblRoaXMgc3VtbWFyeSB3YXMgYXV0b21hdGljYWxseSBnZW5lcmF0ZWQgYnkgeW91ciBOZXdzQWdlbnQgTGFtYmRhIGZ1bmN0aW9uLlxuUG93ZXJlZCBieSBBV1MgTGFtYmRhLCBCZWRyb2NrICYgSGFja2VyIE5ld3MgQVBJXG4gIGA7XG59XG4iXX0=